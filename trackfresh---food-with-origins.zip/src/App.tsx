/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  LayoutGrid,
  Boxes,
  Truck,
  QrCode,
  Users,
  TrendingUp,
  UserCheck,
  ShieldCheck,
  AlertTriangle,
  Plus,
  ArrowUpRight,
  TrendingDown,
  CloudRain,
  Droplet,
  Trash2,
  Menu,
  X,
  ChevronRight,
  Leaf,
  Layers,
  Edit3,
  RefreshCw,
  Package,
  MapPin,
  Activity,
  Crosshair,
  ExternalLink,
  Lock,
  Play,
  FileSpreadsheet,
  Search
} from 'lucide-react';
import { useAuth } from './context/AuthContext';
import { BatchItem, CustodyStep, DEFAULT_BATCHES, RouteWaypoint } from './types';
import {
  subscribeToBatches,
  saveBatchToFirestore,
  deleteBatchFromFirestore
} from './services/batchService';
import { TransitMap } from './components/TransitMap';
import { QRGeneratorCard } from './components/QRGeneratorCard';
import { QRScannerEngine } from './components/QRScannerEngine';
import { AuthStaffModal } from './components/AuthStaffModal';
import { DefectReportModal } from './components/DefectReportModal';

type TabType = 'overview' | 'batches' | 'journey' | 'scanner' | 'registry' | 'eco';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

export default function App() {
  const { activeProfile, isCloudSynced } = useAuth();

  const [currentTab, setCurrentTab] = useState<TabType>('overview');
  const [batches, setBatches] = useState<BatchItem[]>(DEFAULT_BATCHES);
  const [activeBatchId, setActiveBatchId] = useState<string>('TF-2026-00125');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState<boolean>(false);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState<boolean>(false);
  const [isDefectModalOpen, setIsDefectModalOpen] = useState<boolean>(false);
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [currentLang, setCurrentLang] = useState<'EN' | 'HI'>('EN');

  // Overview, Registry & Batches Tab Search Queries
  const [overviewSearch, setOverviewSearch] = useState<string>('');
  const [registrySearch, setRegistrySearch] = useState<string>('');
  const [batchesSearch, setBatchesSearch] = useState<string>('');

  // Batch Form State
  const [formBatchId, setFormBatchId] = useState<string>('TF-2026-00125');
  const [formProduct, setFormProduct] = useState<string>('Banana');
  const [formVariety, setFormVariety] = useState<string>('Hybrid Red-5 (GI Certified)');
  const [formFarm, setFormFarm] = useState<string>('GreenValley Agri Farms, Satara');
  const [formMandi, setFormMandi] = useState<string>('Pune Central APMC (Hub-04)');
  const [formQuantity, setFormQuantity] = useState<string>('1,200 Kg (48 Crates)');
  const [packagingTags, setPackagingTags] = useState<{ [key: string]: boolean }>({
    '100% Recyclable Crates': true,
    'Zero Plastic Wrap': true,
    'Biodegradable Tag': true
  });

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  // Subscribe to Firestore batches in real-time
  useEffect(() => {
    const unsubscribe = subscribeToBatches(
      (firestoreBatches) => {
        if (firestoreBatches.length > 0) {
          setBatches(firestoreBatches);
        }
      },
      (error) => {
        console.warn('Real-time listener notice:', error.message);
      }
    );

    return () => unsubscribe();
  }, []);

  // Check URL parameters on mount (e.g., ?batch=TF-2026-00125)
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const urlBatch = params.get('batch') || params.get('id');
      if (urlBatch) {
        const cleanId = urlBatch.toUpperCase();
        setActiveBatchId(cleanId);
        setCurrentTab('journey');
        showToast(`Loaded produce passport for ${cleanId}`, 'success');
      }
    } catch (e) {
      // URL parsing catch
    }
  }, []);

  const activeBatch: BatchItem =
    batches.find((b) => b.id.toUpperCase() === activeBatchId.toUpperCase()) ||
    batches[0] ||
    DEFAULT_BATCHES[0];

  const handleSelectPreset = (preset: {
    id: string;
    product: string;
    variety: string;
    farm: string;
    mandi: string;
    qty: string;
  }) => {
    setFormBatchId(preset.id);
    setFormProduct(preset.product);
    setFormVariety(preset.variety);
    setFormFarm(preset.farm);
    setFormMandi(preset.mandi);
    setFormQuantity(preset.qty);
    showToast(`Loaded certified preset: ${preset.product}`, 'info');
  };

  const handleGenerateRandomId = () => {
    const rand = Math.floor(10000 + Math.random() * 90000);
    setFormBatchId(`TF-2026-${rand}`);
  };

  const handleCreateBatch = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!activeProfile.canCreate) {
      showToast('Only Mandi Administrators can register new batches! Switch role to proceed.', 'error');
      setIsStaffModalOpen(true);
      return;
    }

    const selectedPackaging = Object.keys(packagingTags).filter((k) => packagingTags[k]);

    const newBatch: BatchItem = {
      id: formBatchId,
      product: formProduct,
      variety: formVariety,
      farm: formFarm,
      mandi: formMandi,
      quantity: formQuantity,
      grade: 'Grade A (Premium)',
      registered: 'Just Now',
      condition: 'Fresh Registered · Cold-Chain Normal',
      freshnessScore: 98,
      temp: '4.0 °C',
      price: '₹50 / kg',
      packaging: selectedPackaging,
      route: [
        { name: 'Farm Harvest', lat: 18.5204, lng: 73.8567 },
        { name: formMandi, lat: 18.55, lng: 73.88 }
      ],
      history: [
        {
          stage: '1. Farm Harvest',
          location: formFarm,
          handler: `${activeProfile.displayName} (${activeProfile.roleTitle})`,
          timestamp: 'Just Now',
          status: 'Completed',
          note: 'Signed and saved via APMC portal'
        },
        {
          stage: '2. APMC Mandi Hub',
          location: formMandi,
          handler: `${activeProfile.displayName} (${activeProfile.roleTitle})`,
          timestamp: 'Pending Scan',
          status: 'Pending',
          note: 'Dock inspection scheduled.'
        },
        {
          stage: '3. Cold Transport Dispatch',
          location: 'Reefer Express',
          handler: 'Suresh Patil (Logistics)',
          timestamp: 'Pending Scan',
          status: 'Pending',
          note: 'IoT BLE array active.'
        },
        {
          stage: '4. Retail Store Receipt',
          location: 'Retail Store Node',
          handler: 'Anita Sharma (Store Manager)',
          timestamp: 'Pending Scan',
          status: 'Pending',
          note: 'Intake clearance.'
        },
        {
          stage: '5. Consumer Package Scan',
          location: 'Consumer Checkout QR',
          handler: 'Citizen Customer',
          timestamp: 'Pending Scan',
          status: 'Pending',
          note: 'Final consumer trace.'
        }
      ]
    };

    try {
      await saveBatchToFirestore(newBatch, activeProfile);
      setActiveBatchId(newBatch.id);
      showToast(`Batch ${newBatch.id} signed and stored live in Firestore!`, 'success');
    } catch (err) {
      showToast('Error saving batch to cloud database', 'error');
    }
  };

  const handleDeleteBatch = async () => {
    if (!deleteTargetId) return;
    try {
      await deleteBatchFromFirestore(deleteTargetId);
      setBatches((prev) => prev.filter((b) => b.id !== deleteTargetId));
      showToast(`Batch ${deleteTargetId} permanently deleted from Firestore`, 'error');
      setDeleteTargetId(null);
      if (activeBatchId === deleteTargetId && batches.length > 1) {
        const remaining = batches.filter((b) => b.id !== deleteTargetId);
        setActiveBatchId(remaining[0].id);
      }
    } catch (err) {
      showToast('Failed to delete batch from database', 'error');
    }
  };

  const exportBatchesToCSV = () => {
    if (!batches || batches.length === 0) {
      showToast('No batches available to export', 'error');
      return;
    }

    const headers = [
      'Batch ID',
      'Produce / Crop',
      'Cultivar / Variety',
      'Origin Farm Plot',
      'APMC Mandi Hub',
      'Quantity / Crates',
      'Quality Grade',
      'Registration Date',
      'Condition / Status',
      'Freshness Score (/100)',
      'Temperature',
      'Retail Price',
      'Sustainable Packaging',
      'Latest Custody Stage',
      'Current Handler',
      'Logged GPS Waypoints',
      'Last Updated'
    ];

    const escapeCSV = (val: any): string => {
      if (val === undefined || val === null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const csvRows = batches.map((b) => {
      const latestHistory =
        b.history && b.history.length > 0 ? b.history[b.history.length - 1] : null;
      const packagingStr =
        b.packaging && b.packaging.length > 0
          ? b.packaging.join('; ')
          : 'Standard Recyclable';
      const waypointsCount = b.route ? b.route.length : 0;

      return [
        escapeCSV(b.id),
        escapeCSV(b.product),
        escapeCSV(b.variety),
        escapeCSV(b.farm),
        escapeCSV(b.mandi),
        escapeCSV(b.quantity),
        escapeCSV(b.grade),
        escapeCSV(b.registered),
        escapeCSV(b.condition),
        escapeCSV(b.freshnessScore),
        escapeCSV(b.temp),
        escapeCSV(b.price),
        escapeCSV(packagingStr),
        escapeCSV(latestHistory ? latestHistory.stage : 'Registered'),
        escapeCSV(latestHistory ? latestHistory.handler : 'Mandi Officer'),
        escapeCSV(waypointsCount),
        escapeCSV(b.updatedAt || new Date().toISOString())
      ].join(',');
    });

    // UTF-8 BOM for Microsoft Excel / Sheets compatibility
    const csvContent = '\uFEFF' + [headers.join(','), ...csvRows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    const dateStr = new Date().toISOString().split('T')[0];
    link.setAttribute('href', url);
    link.setAttribute('download', `TrackFresh_APMC_Batches_${dateStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    showToast(`Exported ${batches.length} crop batches to CSV successfully!`, 'success');
  };

  const tagDeviceGPSLocation = () => {
    const current = activeBatch;
    const lastPoint =
      current.route && current.route.length > 0
        ? current.route[current.route.length - 1]
        : { lat: 18.5204, lng: 73.8567 };

    let lat = lastPoint.lat + (Math.random() * 0.04 - 0.02);
    let lng = lastPoint.lng + (Math.random() * 0.04 - 0.02);

    const updateAndSave = (coords: { lat: number; lng: number }) => {
      const latStr = `${Math.abs(coords.lat).toFixed(4)}° ${coords.lat >= 0 ? 'N' : 'S'}`;
      const lngStr = `${Math.abs(coords.lng).toFixed(4)}° ${coords.lng >= 0 ? 'E' : 'W'}`;

      const newWaypoint: RouteWaypoint = {
        name: `${activeProfile.roleTitle} Tagged (${latStr}, ${lngStr})`,
        lat: coords.lat,
        lng: coords.lng
      };

      const updatedRoute = [...(current.route || []), newWaypoint];
      const stageIdx = activeProfile.stageIndex;
      const history = [...(current.history || [])];

      if (history[stageIdx]) {
        history[stageIdx] = {
          ...history[stageIdx],
          status: 'Completed',
          note: `GPS Tagged: ${latStr}, ${lngStr} (${activeProfile.facility}) ✓`
        };
      }

      const updatedBatch: BatchItem = {
        ...current,
        route: updatedRoute,
        history,
        updatedAt: new Date().toISOString()
      };

      saveBatchToFirestore(updatedBatch, activeProfile)
        .then(() => {
          showToast(`GPS Location Tagged & Pushed to Firestore: ${latStr}, ${lngStr}`);
        })
        .catch(() => {
          showToast('Failed to update GPS in cloud', 'error');
        });
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => updateAndSave({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        () => updateAndSave({ lat, lng }),
        { timeout: 1500 }
      );
    } else {
      updateAndSave({ lat, lng });
    }
  };

  const filteredOverviewBatches = batches.filter((b) => {
    const q = overviewSearch.toLowerCase();
    return (
      b.id.toLowerCase().includes(q) ||
      b.product.toLowerCase().includes(q) ||
      b.farm.toLowerCase().includes(q) ||
      b.mandi.toLowerCase().includes(q)
    );
  });

  const filteredRegistryBatches = batches.filter((b) => {
    const q = registrySearch.toLowerCase();
    return (
      b.id.toLowerCase().includes(q) ||
      b.product.toLowerCase().includes(q) ||
      b.farm.toLowerCase().includes(q) ||
      b.mandi.toLowerCase().includes(q) ||
      b.grade.toLowerCase().includes(q)
    );
  });

  const filteredBatchesTabList = batches.filter((b) => {
    const q = batchesSearch.toLowerCase().trim();
    if (!q) return true;
    return (
      b.id.toLowerCase().includes(q) ||
      b.product.toLowerCase().includes(q) ||
      b.variety.toLowerCase().includes(q) ||
      b.farm.toLowerCase().includes(q) ||
      b.mandi.toLowerCase().includes(q) ||
      b.grade.toLowerCase().includes(q) ||
      b.condition.toLowerCase().includes(q)
    );
  });

  return (
    <div className="h-screen h-[100dvh] w-full flex overflow-hidden text-slate-800 bg-[#f8fbf7]">
      {/* Toast Notification Container */}
      <div className="fixed top-3 right-3 sm:top-5 sm:right-5 z-50 space-y-2 pointer-events-none max-w-[90vw]">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`p-3 sm:p-3.5 rounded-xl shadow-xl text-xs font-bold font-mono border flex items-center gap-2 transition-all duration-300 pointer-events-auto ${
              toast.type === 'success'
                ? 'bg-emerald-950 text-white border-emerald-700'
                : toast.type === 'error'
                ? 'bg-red-950 text-white border-red-700'
                : 'bg-slate-900 text-white border-slate-700'
            }`}
          >
            {toast.type === 'success' ? (
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            )}
            <span className="truncate">{toast.message}</span>
          </div>
        ))}
      </div>

      {/* LEFT SIDEBAR NAVIGATION */}
      <aside
        className={`w-64 sm:w-72 bg-white border-r border-[#e2ece0] flex flex-col justify-between h-screen h-[100dvh] sticky top-0 z-50 shrink-0 transition-transform duration-300 md:translate-x-0 no-scrollbar ${
          mobileSidebarOpen ? 'translate-x-0 fixed shadow-2xl' : '-translate-x-full fixed md:relative'
        }`}
      >
        <div className="p-5 space-y-6 overflow-y-auto no-scrollbar">
          {/* Brand Header */}
          <div
            className="flex items-center gap-3 cursor-pointer select-none"
            onClick={() => {
              setCurrentTab('overview');
              setMobileSidebarOpen(false);
            }}
          >
            <div className="w-10 h-10 rounded-xl bg-brand-800 flex items-center justify-center text-white shadow-md shrink-0">
              <Leaf className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">
                  TrackFresh
                </span>
                <span className="text-[10px] font-bold text-slate-400 font-mono">®</span>
              </div>
              <p className="text-[10px] font-bold text-brand-600 uppercase tracking-wider font-mono">
                Food With Origins
              </p>
            </div>
          </div>

          {/* User Role Workspace Card */}
          <div className="p-3.5 rounded-2xl bg-[#f3f7f2] border border-[#e2ece0] flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="w-9 h-9 rounded-xl bg-brand-800 text-white font-black text-xs font-mono flex items-center justify-center shrink-0 shadow-sm">
                {activeProfile.initials}
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-extrabold text-slate-900 truncate">
                  {activeProfile.displayName}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {activeProfile.roleTitle}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsStaffModalOpen(true)}
              className="p-1.5 text-brand-800 hover:bg-brand-100 rounded-lg transition cursor-pointer"
              title="Switch User Role or Sign In"
            >
              <UserCheck className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Menu */}
          <nav className="space-y-1">
            <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 px-3 mb-2 font-mono">
              WORKSPACE
            </div>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('overview');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-3 transition cursor-pointer ${
                currentTab === 'overview'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span>Overview</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('batches');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                currentTab === 'batches'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <div className="flex items-center gap-3">
                <Boxes className="w-4 h-4" />
                <span>Batches & crates</span>
              </div>
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-slate-100 text-slate-600 rounded-full">
                {batches.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('journey');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
                currentTab === 'journey'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <Truck className="w-4 h-4" />
              <span>Journey log</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('scanner');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
                currentTab === 'scanner'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <QrCode className="w-4 h-4" />
              <span>QR labels & scan</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('registry');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
                currentTab === 'registry'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>APMC Registry</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setCurrentTab('eco');
                setMobileSidebarOpen(false);
              }}
              className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-3 transition cursor-pointer ${
                currentTab === 'eco'
                  ? 'nav-item-active text-brand-800'
                  : 'text-slate-600 nav-item-hover'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Business insights</span>
            </button>
          </nav>

          {/* Promo Note */}
          <div className="p-4 rounded-2xl bg-[#eaf1e7] border border-[#d0dfcc] space-y-2">
            <div className="w-8 h-8 rounded-lg bg-brand-800 flex items-center justify-center text-emerald-300 shadow-sm">
              <Leaf className="w-4 h-4" />
            </div>
            <h4 className="text-xs font-extrabold text-slate-900">Small label. Full story.</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              Scan with any mobile phone to trace farm-to-table origin instantly across Firestore.
            </p>
          </div>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-[#e2ece0] bg-white flex items-center justify-between text-[11px] text-slate-500 font-mono shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="truncate max-w-[140px]">{activeProfile.facility}</span>
          </div>
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(false)}
            className="md:hidden text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {mobileSidebarOpen && (
        <div
          onClick={() => setMobileSidebarOpen(false)}
          className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-30 md:hidden"
        />
      )}

      {/* MAIN WORKSPACE */}
      <div className="flex-1 flex flex-col h-screen h-[100dvh] overflow-y-auto overflow-x-hidden bg-[#f8fbf7] z-10 pb-20 md:pb-6">
        {/* Top Header */}
        <header className="border-b border-[#e2ece0] bg-white/90 backdrop-blur-md sticky top-0 z-30 px-3 sm:px-6 py-2.5 sm:py-3.5 flex items-center justify-between gap-2 safe-area-top">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileSidebarOpen(true)}
              className="md:hidden p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 cursor-pointer shrink-0"
              title="Open Navigation"
            >
              <Menu className="w-5 h-5" />
            </button>

            <nav className="flex items-center gap-1.5 sm:gap-2 text-xs text-slate-500 font-medium truncate">
              <span className="hidden sm:inline">Workspace</span>
              <ChevronRight className="hidden sm:inline w-3.5 h-3.5 text-slate-400" />
              <span className="font-bold text-slate-900 capitalize truncate">{currentTab}</span>
            </nav>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
            {/* Live Firestore Cloud Sync Pill */}
            <div
              className={`inline-flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1 rounded-full text-[10px] sm:text-xs font-semibold shadow-sm ${
                isCloudSynced
                  ? 'bg-emerald-50 border border-emerald-300 text-emerald-800'
                  : 'bg-amber-50 border border-amber-300 text-amber-800'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full shrink-0 ${
                  isCloudSynced ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                }`}
              />
              <span className="hidden sm:inline">{isCloudSynced ? 'Firebase Cloud Synced' : 'Sync Active'}</span>
              <span className="sm:hidden">{isCloudSynced ? 'Synced' : 'Active'}</span>
            </div>

            {/* Auth / Role Display */}
            <button
              type="button"
              onClick={() => setIsStaffModalOpen(true)}
              className="px-2 sm:px-3 py-1.5 bg-[#f0f7f2] hover:bg-brand-100 text-brand-800 border border-brand-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer max-w-[150px] sm:max-w-none"
            >
              <UserCheck className="w-3.5 h-3.5 text-brand-600 shrink-0" />
              <span className="hidden sm:inline truncate">
                {activeProfile.displayName} ({activeProfile.roleTitle})
              </span>
              <span className="sm:hidden font-mono text-[11px]">{activeProfile.initials}</span>
            </button>

            {/* Defect Report Button */}
            <button
              type="button"
              onClick={() => setIsDefectModalOpen(true)}
              className="px-2 sm:px-2.5 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 rounded-xl text-xs font-semibold transition flex items-center gap-1 cursor-pointer shrink-0"
              title="Report Defect"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0" />
              <span className="hidden sm:inline">Defect</span>
            </button>

            {/* Language Switcher */}
            <button
              type="button"
              onClick={() => {
                const next = currentLang === 'EN' ? 'HI' : 'EN';
                setCurrentLang(next);
                showToast(`Language switched to ${next === 'EN' ? 'English' : 'Hindi'}`);
              }}
              className="px-1.5 sm:px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-mono font-bold cursor-pointer shrink-0"
            >
              {currentLang === 'EN' ? 'EN' : 'हिं'}
            </button>
          </div>
        </header>

        {/* MAIN BODY CONTENTS */}
        <main className="flex-1 p-3.5 sm:p-6 lg:p-10 max-w-7xl w-full mx-auto space-y-6 sm:space-y-8">
          {/* TAB 1: OVERVIEW */}
          {currentTab === 'overview' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
                <div className="space-y-1">
                  <div className="text-[11px] font-bold uppercase tracking-widest text-slate-400 font-mono">
                    FROM FARM TO TABLE, WITH CONFIDENCE
                  </div>
                  <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                    Every crate has a story.
                  </h1>
                  <p className="text-xs sm:text-sm text-slate-500 font-medium">
                    Real-time synchronized produce tracking across all connected smartphones & hubs.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setCurrentTab('batches')}
                  className="px-5 py-2.5 bg-brand-800 hover:bg-brand-700 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-md shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Register a batch</span>
                </button>
              </div>

              {/* Hero Card */}
              <div className="bg-[#e9f0e7] border border-[#d0dfcc] rounded-3xl p-6 sm:p-8 lg:p-10 relative overflow-hidden flex flex-col lg:flex-row items-center justify-between gap-8 shadow-sm">
                <div className="space-y-5 max-w-xl z-10">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/80 border border-[#d0dfcc] text-brand-800">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    <span className="text-[11px] uppercase tracking-wider font-mono">
                      TRACEABILITY STARTS HERE
                    </span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 leading-tight">
                    Good produce.
                    <br />A journey you can follow.
                  </h2>

                  <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
                    Register your harvest, label every crate with an Eco QR passport, and sync custody handovers live to Firestore database across devices.
                  </p>

                  <div>
                    <button
                      type="button"
                      onClick={() => setCurrentTab('batches')}
                      className="px-5 py-2.5 bg-white hover:bg-slate-50 text-slate-900 border border-[#c2d4bf] font-extrabold rounded-xl text-xs transition flex items-center gap-2 shadow-sm cursor-pointer"
                    >
                      <span>Create your first batch</span>
                      <ArrowUpRight className="w-4 h-4 text-slate-500" />
                    </button>
                  </div>
                </div>

                {/* Hero Artwork Graphic */}
                <div className="shrink-0 w-full lg:w-auto flex justify-center z-10">
                  <svg
                    viewBox="0 0 380 210"
                    className="w-full max-w-[340px] sm:max-w-[380px] h-auto drop-shadow-md overflow-visible"
                  >
                    <g transform="translate(40, 80)">
                      <circle cx="90" cy="15" r="30" fill="#ef4444" />
                      <circle cx="82" cy="0" r="7" fill="#22c55e" />
                      <circle cx="150" cy="20" r="26" fill="#dc2626" />
                      <path d="M190 28 L235 -10 L248 0 L200 40 Z" fill="#f97316" />
                      <path d="M235 -10 Q255 -30 265 -20 Q250 -5 235 -10" fill="#15803d" />
                      <path d="M110 -5 L130 -35 L145 -30 L120 0 Z" fill="#4ade80" />

                      <rect x="20" y="30" width="260" height="80" rx="8" fill="#d97706" opacity="0.9" />
                      <rect x="15" y="25" width="270" height="28" rx="5" fill="#b45309" stroke="#78350f" strokeWidth="2" />
                      <rect x="15" y="60" width="270" height="28" rx="5" fill="#b45309" stroke="#78350f" strokeWidth="2" />
                      <rect x="15" y="95" width="270" height="20" rx="5" fill="#92400e" stroke="#78350f" strokeWidth="2" />
                      <rect x="25" y="20" width="16" height="98" rx="3" fill="#78350f" />
                      <rect x="260" y="20" width="16" height="98" rx="3" fill="#78350f" />

                      <rect x="70" y="45" width="150" height="30" rx="6" fill="#fef3c7" stroke="#b45309" strokeWidth="1.5" strokeDasharray="4 2" />
                      <path d="M82 60 Q87 52 92 60" fill="none" stroke="#15803d" strokeWidth="2" />
                      <text x="96" y="64" fontSize="9" fontWeight="900" fill="#15803d" fontFamily="sans-serif" letterSpacing="0.5">
                        FRESH FROM THE FARM
                      </text>
                    </g>

                    <g transform="translate(10, 15)">
                      <rect x="30" y="10" width="190" height="65" rx="14" fill="#ffffff" stroke="#d0dfcc" strokeWidth="2" filter="drop-shadow(0 10px 15px rgba(0,0,0,0.06))" />
                      <rect x="42" y="20" width="45" height="45" rx="6" fill="#1b4332" />
                      <rect x="48" y="26" width="12" height="12" fill="#ffffff" />
                      <rect x="51" y="29" width="6" height="6" fill="#1b4332" />
                      <rect x="69" y="26" width="12" height="12" fill="#ffffff" />
                      <rect x="72" y="29" width="6" height="6" fill="#1b4332" />
                      <rect x="48" y="47" width="12" height="12" fill="#ffffff" />
                      <rect x="51" y="50" width="6" height="6" fill="#1b4332" />
                      <rect x="67" y="47" width="6" height="6" fill="#ffffff" />
                      <rect x="75" y="53" width="6" height="6" fill="#ffffff" />

                      <text x="96" y="32" fontSize="8" fontWeight="800" fill="#6b7280" fontFamily="sans-serif" letterSpacing="1">
                        TRACKFRESH
                      </text>
                      <text x="96" y="46" fontSize="12" fontWeight="900" fill="#111827" fontFamily="sans-serif">
                        FARM → TABLE
                      </text>
                      <text x="96" y="60" fontSize="9" fontWeight="600" fill="#10b981" fontFamily="sans-serif">
                        One scan. Live cloud sync.
                      </text>
                    </g>
                  </svg>
                </div>
              </div>

              {/* 3 Stat Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-2 shadow-sm">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono">
                    REGISTERED BATCHES
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">
                    {batches.length}
                  </div>
                  <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    <TrendingUp className="w-3.5 h-3.5" />
                    <span>Active across APMC hubs</span>
                  </div>
                </div>

                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-2 shadow-sm">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono">
                    CRATES LABELLED
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">6,140</div>
                  <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>100% Recyclable Eco Crates</span>
                  </div>
                </div>

                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-2 shadow-sm">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 font-mono">
                    PRODUCE REGISTERED
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">48.2 Tons</div>
                  <div className="text-xs font-semibold text-emerald-700 flex items-center gap-1">
                    <Leaf className="w-3.5 h-3.5" />
                    <span>18.1t CO₂e Offset Saved</span>
                  </div>
                </div>
              </div>

              {/* Active Crop Batches Table */}
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base">Active Crop Batches</h3>
                    <p className="text-xs text-slate-500">
                      Live feed of verified produce dispatches synchronized in Firestore
                    </p>
                  </div>

                  <input
                    type="text"
                    value={overviewSearch}
                    onChange={(e) => setOverviewSearch(e.target.value)}
                    placeholder="Search crop, farm or batch..."
                    className="bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:border-brand-800 focus:outline-none w-full sm:w-64 font-medium"
                  />
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#f8fbf7] text-slate-500 font-mono text-[10px] uppercase border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3">PRODUCE / BATCH</th>
                        <th className="px-4 py-3">ORIGIN FARM</th>
                        <th className="px-4 py-3">QUANTITY</th>
                        <th className="px-4 py-3">CONDITION</th>
                        <th className="px-4 py-3">REGISTERED</th>
                        <th className="px-4 py-3 text-right">ACTION</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {filteredOverviewBatches.map((b) => (
                        <tr key={b.id} className="hover:bg-slate-50 transition">
                          <td className="px-4 py-3.5">
                            <div className="font-extrabold text-slate-900 text-xs">{b.product}</div>
                            <div className="text-[10px] font-mono text-brand-800 font-bold">
                              {b.id}
                            </div>
                          </td>
                          <td className="px-4 py-3.5 text-xs text-slate-600">{b.farm}</td>
                          <td className="px-4 py-3.5 font-mono font-bold text-xs text-slate-800">
                            {b.quantity}
                          </td>
                          <td className="px-4 py-3.5">
                            <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>{' '}
                              {b.condition}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-slate-500 font-mono text-[10px]">
                            {b.registered}
                          </td>
                          <td className="px-4 py-3.5 text-right">
                            <div className="flex items-center justify-end gap-2.5">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveBatchId(b.id);
                                  setCurrentTab('journey');
                                }}
                                className="px-3 py-1 bg-white border border-[#c2d4bf] hover:bg-slate-50 text-brand-800 font-bold text-xs rounded-lg transition flex items-center gap-1 shadow-sm cursor-pointer"
                              >
                                View <span className="text-xs">→</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTargetId(b.id)}
                                className="p-1 text-red-500 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                title="Delete Batch"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BATCHES & CRATES */}
          {currentTab === 'batches' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-brand-50 text-brand-800 border border-brand-200 mb-2">
                    <Boxes className="w-3.5 h-3.5" /> Batch Registration & Tagging Hub
                  </div>
                  <h2 className="text-2xl font-extrabold text-slate-900">
                    Create & Sign Produce QR Passport
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    Issue digital passports saved immediately to cloud Firestore database.
                  </p>
                </div>

                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    type="button"
                    onClick={exportBatchesToCSV}
                    className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-800 border border-[#c2d4bf] font-extrabold rounded-xl text-xs transition flex items-center gap-2 cursor-pointer shadow-sm"
                    title="Export all current batches as a CSV spreadsheet for offline APMC reporting"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                    <span>Export Batches CSV</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      handleSelectPreset({
                        id: 'TF-2026-00125',
                        product: 'Banana',
                        variety: 'Hybrid Red-5 (GI Certified)',
                        farm: 'GreenValley Agri Farms, Satara',
                        mandi: 'Pune Central APMC (Hub-04)',
                        qty: '1,200 Kg (48 Crates)'
                      })
                    }
                    className="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold rounded-xl text-xs transition flex items-center gap-2 cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4 text-emerald-600" /> Load Banana Preset
                  </button>
                </div>
              </div>

              {/* Role Alert Banner */}
              <div className="p-4 rounded-2xl bg-brand-50 border border-brand-200 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-brand-800 text-white flex items-center justify-center shrink-0">
                    {activeProfile.canCreate ? (
                      <ShieldCheck className="w-5 h-5 text-emerald-300" />
                    ) : (
                      <Lock className="w-5 h-5 text-amber-300" />
                    )}
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-slate-900">
                      {activeProfile.canCreate
                        ? `${activeProfile.roleTitle} Creator Mode Active`
                        : `Read-Only / Scanner Mode (${activeProfile.roleTitle})`}
                    </h4>
                    <p className="text-[11px] text-slate-600">
                      {activeProfile.canCreate
                        ? `Logged in as ${activeProfile.displayName}. Full authority to sign and register new batches.`
                        : `Logged in as ${activeProfile.displayName}. Mandi Admin privileges are required to create batches.`}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsStaffModalOpen(true)}
                  className="px-3 py-1.5 bg-white border border-[#d0dfcc] rounded-xl text-xs font-bold text-slate-800 hover:bg-slate-50 transition shrink-0 cursor-pointer"
                >
                  Switch Role
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Form Column */}
                <div className="lg:col-span-7 space-y-6">
                  {/* Preset Buttons */}
                  <div className="bg-white border border-[#e2ece0] rounded-2xl p-5 space-y-3 shadow-sm">
                    <div className="flex items-center justify-between">
                      <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2 font-mono">
                        <Layers className="w-4 h-4 text-brand-800" /> CERTIFIED CROP PRESETS
                      </h3>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Click to quick fill
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {[
                        {
                          id: 'TF-2026-00125',
                          product: 'Banana',
                          variety: 'Hybrid Red-5 (GI Certified)',
                          farm: 'GreenValley Agri Farms, Satara',
                          mandi: 'Pune Central APMC (Hub-04)',
                          qty: '1,200 Kg (48 Crates)'
                        },
                        {
                          id: 'TF-2026-00127',
                          product: 'Alphonso Mangoes',
                          variety: 'Ratnagiri Export Grade',
                          farm: 'Ratnagiri Coastal Orchards',
                          mandi: 'Vashi APMC Mumbai (Hub-01)',
                          qty: '336 Crates (3,360 Pcs)'
                        },
                        {
                          id: 'TF-2026-00129',
                          product: 'Kinnaur Apples',
                          variety: 'Sweet Juicy Grade A',
                          farm: 'High-Land Orchards, HP',
                          mandi: 'Azadpur APMC Delhi (Hub-02)',
                          qty: '2,400 Kg (320 Boxes)'
                        }
                      ].map((preset) => (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => handleSelectPreset(preset)}
                          className="p-2.5 bg-[#f8fbf7] hover:bg-brand-50 border border-[#d0dfcc] hover:border-brand-300 rounded-xl text-left transition space-y-1 cursor-pointer"
                        >
                          <div className="text-[10px] font-mono text-brand-800 font-bold">
                            {preset.id}
                          </div>
                          <div className="text-xs font-extrabold text-slate-800 truncate">
                            {preset.product}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Form */}
                  <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-5 shadow-sm">
                    <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
                      <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                        <Edit3 className="w-4 h-4 text-brand-800" /> Batch Parameters
                      </h3>
                      <button
                        type="button"
                        onClick={handleGenerateRandomId}
                        className="text-xs text-brand-800 hover:underline flex items-center gap-1 font-mono font-bold cursor-pointer"
                      >
                        <RefreshCw className="w-3 h-3" /> Auto ID
                      </button>
                    </div>

                    <form onSubmit={handleCreateBatch} className="space-y-4">
                      <fieldset disabled={!activeProfile.canCreate} className="space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Batch ID
                            </label>
                            <input
                              type="text"
                              value={formBatchId}
                              onChange={(e) => setFormBatchId(e.target.value.toUpperCase())}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-brand-800 font-mono font-bold focus:border-brand-800 focus:outline-none"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Crop / Commodity
                            </label>
                            <input
                              type="text"
                              value={formProduct}
                              onChange={(e) => setFormProduct(e.target.value)}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:border-brand-800 focus:outline-none"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Cultivar / Variety
                            </label>
                            <input
                              type="text"
                              value={formVariety}
                              onChange={(e) => setFormVariety(e.target.value)}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:border-brand-800 focus:outline-none"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Origin Farm Plot
                            </label>
                            <input
                              type="text"
                              value={formFarm}
                              onChange={(e) => setFormFarm(e.target.value)}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:border-brand-800 focus:outline-none"
                              required
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              APMC Mandi Hub
                            </label>
                            <select
                              value={formMandi}
                              onChange={(e) => setFormMandi(e.target.value)}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:border-brand-800 focus:outline-none"
                            >
                              <option value="Pune Central APMC (Hub-04)">
                                Pune Central APMC (Hub-04)
                              </option>
                              <option value="Vashi APMC Mumbai (Hub-01)">
                                Vashi APMC Mumbai (Hub-01)
                              </option>
                              <option value="Azadpur APMC Delhi (Hub-02)">
                                Azadpur APMC Delhi (Hub-02)
                              </option>
                              <option value="Lasalgaon APMC Nashik (Hub-09)">
                                Lasalgaon APMC Nashik (Hub-09)
                              </option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Quantity / Pack Count
                            </label>
                            <input
                              type="text"
                              value={formQuantity}
                              onChange={(e) => setFormQuantity(e.target.value)}
                              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs text-slate-800 font-semibold focus:border-brand-800 focus:outline-none"
                            />
                          </div>
                        </div>

                        <div className="pt-2">
                          <label className="block text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
                            <Package className="w-4 h-4 text-emerald-600" /> Sustainable Packaging Tags
                          </label>
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            {['100% Recyclable Crates', 'Zero Plastic Wrap', 'Biodegradable Tag'].map(
                              (tag) => (
                                <label
                                  key={tag}
                                  className="flex items-center gap-2 p-2.5 bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl cursor-pointer"
                                >
                                  <input
                                    type="checkbox"
                                    checked={packagingTags[tag] || false}
                                    onChange={(e) =>
                                      setPackagingTags((prev) => ({
                                        ...prev,
                                        [tag]: e.target.value !== undefined ? e.target.checked : false
                                      }))
                                    }
                                    className="accent-brand-800 rounded"
                                  />
                                  <span className="text-[11px] font-semibold text-slate-700">
                                    {tag}
                                  </span>
                                </label>
                              )
                            )}
                          </div>
                        </div>

                        <button
                          type="submit"
                          disabled={!activeProfile.canCreate}
                          className={`w-full py-3 rounded-xl text-xs font-extrabold transition flex items-center justify-center gap-2 shadow-md ${
                            activeProfile.canCreate
                              ? 'bg-brand-800 hover:bg-brand-700 text-white cursor-pointer'
                              : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                          }`}
                        >
                          <QrCode className="w-4 h-4" /> Sign & Save Batch to Cloud
                        </button>
                      </fieldset>
                    </form>
                  </div>
                </div>

                {/* Printable QR Passport Column */}
                <div className="lg:col-span-5 space-y-6">
                  <QRGeneratorCard
                    batchId={formBatchId}
                    batchDetails={{
                      product: formProduct,
                      variety: formVariety,
                      farm: formFarm,
                      mandi: formMandi,
                      quantity: formQuantity,
                      packaging: Object.keys(packagingTags).filter((k) => packagingTags[k])
                    }}
                    onVerifyBatch={(id) => {
                      setActiveBatchId(id);
                      setCurrentTab('scanner');
                    }}
                    showToast={showToast}
                  />
                </div>
              </div>

              {/* Real-time Filterable Batches Directory */}
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-5 sm:p-6 space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                      <Boxes className="w-4 h-4 text-brand-800" />
                      <span>Current Registered Batches Directory</span>
                    </h3>
                    <p className="text-xs text-slate-500">
                      Real-time filtered list of crop batches synchronized in Firestore
                    </p>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <div className="relative flex-1 sm:w-80">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                      <input
                        type="text"
                        value={batchesSearch}
                        onChange={(e) => setBatchesSearch(e.target.value)}
                        placeholder="Search batch ID, crop, variety, farm or mandi..."
                        className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl pl-9 pr-8 py-2 text-xs text-slate-800 font-medium focus:border-brand-800 focus:outline-none"
                      />
                      {batchesSearch && (
                        <button
                          type="button"
                          onClick={() => setBatchesSearch('')}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-0.5 cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                    <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 px-2.5 py-1.5 rounded-xl shrink-0">
                      {filteredBatchesTabList.length} of {batches.length}
                    </span>
                  </div>
                </div>

                {filteredBatchesTabList.length === 0 ? (
                  <div className="p-8 text-center bg-[#f8fbf7] border border-dashed border-[#d0dfcc] rounded-2xl space-y-2">
                    <p className="text-xs font-bold text-slate-600">
                      No matching batches found for "{batchesSearch}"
                    </p>
                    <button
                      type="button"
                      onClick={() => setBatchesSearch('')}
                      className="text-xs text-brand-800 font-bold hover:underline cursor-pointer"
                    >
                      Clear search filter
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                    {filteredBatchesTabList.map((b) => {
                      const isSelected = formBatchId === b.id;
                      return (
                        <div
                          key={b.id}
                          className={`p-4 rounded-2xl border transition space-y-3 cursor-pointer ${
                            isSelected
                              ? 'bg-brand-50/70 border-brand-300 shadow-sm'
                              : 'bg-[#f8fbf7] border-[#d0dfcc] hover:bg-slate-50'
                          }`}
                          onClick={() => {
                            setFormBatchId(b.id);
                            setFormProduct(b.product);
                            setFormVariety(b.variety);
                            setFormFarm(b.farm);
                            setFormMandi(b.mandi);
                            setFormQuantity(b.quantity);
                            setActiveBatchId(b.id);
                            showToast(`Selected batch ${b.id} in passport editor`);
                          }}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-[10px] font-mono font-extrabold text-brand-800 bg-white px-2 py-0.5 rounded-md border border-brand-200">
                                {b.id}
                              </span>
                              <h4 className="font-extrabold text-slate-900 text-xs mt-1.5">
                                {b.product}
                              </h4>
                              <p className="text-[11px] text-slate-500 truncate max-w-[200px]">
                                {b.variety}
                              </p>
                            </div>
                            <span
                              className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded ${
                                b.grade && b.grade.includes('Grade A')
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {b.grade.split(' ')[0]}
                            </span>
                          </div>

                          <div className="text-[11px] text-slate-600 space-y-1 font-medium pt-1 border-t border-slate-200/60">
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="text-slate-400">Farm:</span>
                              <span className="text-slate-700 truncate max-w-[150px]">{b.farm}</span>
                            </div>
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="text-slate-400">Mandi:</span>
                              <span className="text-slate-700 truncate max-w-[150px]">{b.mandi}</span>
                            </div>
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="text-slate-400">Quantity:</span>
                              <span className="text-slate-800 font-mono font-bold">{b.quantity}</span>
                            </div>
                          </div>

                          <div className="pt-2 flex items-center justify-between gap-2 border-t border-slate-200/60 text-[11px]">
                            <span className="text-[10px] font-mono text-emerald-700 font-bold">
                              Score: {b.freshnessScore}/100
                            </span>
                            <div
                              className="flex items-center gap-1.5"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <button
                                type="button"
                                onClick={() => {
                                  setFormBatchId(b.id);
                                  setFormProduct(b.product);
                                  setFormVariety(b.variety);
                                  setFormFarm(b.farm);
                                  setFormMandi(b.mandi);
                                  setFormQuantity(b.quantity);
                                  setActiveBatchId(b.id);
                                  showToast(`Loaded ${b.id} into editor`);
                                }}
                                className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[10px] font-bold transition cursor-pointer"
                              >
                                Edit
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveBatchId(b.id);
                                  setCurrentTab('journey');
                                }}
                                className="px-2 py-1 bg-brand-800 hover:bg-brand-700 text-white rounded-lg text-[10px] font-bold transition cursor-pointer"
                              >
                                Journey →
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: JOURNEY LOG */}
          {currentTab === 'journey' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="bg-[#1b4332] text-white rounded-3xl p-6 lg:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl relative overflow-hidden">
                <div className="space-y-2 z-10">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-3 py-1 bg-emerald-900/80 text-emerald-300 font-mono font-bold text-xs rounded-full border border-emerald-700">
                      {activeBatch.id}
                    </span>
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold rounded-full border border-emerald-500/30">
                      APMC Net-Zero Verified
                    </span>
                    <span className="text-[10px] font-mono text-emerald-300">
                      Route ID: #RL-401_2026
                    </span>
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-black capitalize tracking-tight">
                    {activeBatch.product}
                  </h2>
                  <p className="text-xs text-emerald-100 font-medium">
                    Variety: {activeBatch.variety} · Farm: {activeBatch.farm}
                  </p>
                </div>

                <div className="flex items-center gap-4 z-10 flex-wrap">
                  <div className="p-3 bg-emerald-950/80 border border-emerald-800 rounded-2xl text-center min-w-[110px]">
                    <div className="text-[9px] font-mono font-bold uppercase text-emerald-400">
                      FRESHNESS INDEX
                    </div>
                    <div className="text-xl font-black font-mono text-white">
                      {activeBatch.freshnessScore}
                      <span className="text-xs text-emerald-400">/100</span>
                    </div>
                    <div className="text-[9px] font-mono font-bold text-emerald-400">OPTIMAL</div>
                  </div>

                  <div className="p-3 bg-emerald-950/80 border border-emerald-800 rounded-2xl text-center min-w-[130px]">
                    <div className="text-[9px] font-mono font-bold uppercase text-emerald-400">
                      RETAIL PRICE
                    </div>
                    <div className="text-xl font-black font-mono text-white">
                      {activeBatch.price.split(' ')[0]}
                      <span className="text-xs text-emerald-400">/kg</span>
                    </div>
                    <div className="text-[9px] font-mono font-bold text-emerald-400">
                      {activeBatch.grade}
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <button
                      type="button"
                      onClick={() => setCurrentTab('scanner')}
                      className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold rounded-xl text-xs transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                    >
                      <QrCode className="w-4 h-4" /> Scan & Log Handover
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteTargetId(activeBatch.id)}
                      className="px-3.5 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-200 border border-red-800 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" /> Delete Batch
                    </button>
                  </div>
                </div>
              </div>

              {/* Transit Map & IoT Sensor Log */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                <div className="lg:col-span-7 bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-4 shadow-sm">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider font-mono flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-brand-800" /> FARM-TO-TABLE GPS TRANSIT ROUTE
                    </h3>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={tagDeviceGPSLocation}
                        className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-[11px] font-bold transition flex items-center gap-1 cursor-pointer shadow-sm"
                      >
                        <Crosshair className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Tag Location (GPS)</span>
                      </button>
                      <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-bold">
                        {activeBatch.route ? activeBatch.route.length : 0} Waypoints Logged
                      </span>
                    </div>
                  </div>

                  <TransitMap
                    waypoints={activeBatch.route || []}
                    activeBatchId={activeBatch.id}
                  />
                </div>

                <div className="lg:col-span-5 bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-4 shadow-sm flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3">
                      <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider font-mono flex items-center gap-2">
                        <Activity className="w-4 h-4 text-emerald-600" /> COLD-CHAIN SENSOR LOG
                      </h3>
                      <span className="text-[10px] font-mono text-slate-400">Sensor #RF-9904</span>
                    </div>

                    <div className="space-y-4 py-2">
                      <div className="flex items-center justify-between text-xs font-mono font-bold">
                        <span className="text-slate-500">TARGET: 4.0°C - 12.5°C</span>
                        <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                          STABLE ({activeBatch.temp}) ✓
                        </span>
                      </div>

                      <div className="h-36 w-full bg-[#f8fbf7] rounded-xl border border-[#d0dfcc] p-3 flex items-end">
                        <svg className="w-full h-full overflow-visible" viewBox="0 0 300 100">
                          <polyline
                            fill="none"
                            stroke="#2d6a4f"
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            points="10,70 90,45 170,52 250,48 290,38"
                          />
                          <circle cx="10" cy="70" r="4" fill="#1b4332" />
                          <circle cx="90" cy="45" r="4" fill="#1b4332" />
                          <circle cx="170" cy="52" r="4" fill="#1b4332" />
                          <circle cx="250" cy="48" r="4" fill="#1b4332" />
                          <circle cx="290" cy="38" r="4" fill="#1b4332" />
                        </svg>
                      </div>

                      <div className="flex justify-between text-[10px] font-mono text-slate-400 px-1">
                        <span>Harvest (0h)</span>
                        <span>Mandi (12h)</span>
                        <span>Reefer (24h)</span>
                        <span>Retail (36h)</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl text-[11px] text-slate-600">
                    Continuous IoT BLE telemetry logged via cold storage unit sensor node #RF-9904.
                  </div>
                </div>
              </div>

              {/* 5-Stage Chain of Custody Timeline */}
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 sm:p-8 space-y-6 shadow-sm">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base">
                      5-Stage Chain of Custody Timeline
                    </h3>
                    <p className="text-xs text-slate-500">
                      Automated time-stamped QR handovers synced live to Firestore across devices
                    </p>
                  </div>
                  <span className="text-[11px] font-mono bg-slate-100 text-slate-600 px-3 py-1 rounded-full font-bold">
                    Live Synced Timestamps
                  </span>
                </div>

                <div className="space-y-6 relative before:absolute before:inset-0 before:left-4 before:w-0.5 before:bg-slate-200">
                  {(activeBatch.history || []).map((h: CustodyStep, idx: number) => (
                    <div key={idx} className="flex items-start gap-4 relative z-10">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs shrink-0 font-mono ${
                          h.status === 'Completed'
                            ? 'bg-emerald-500 text-white'
                            : 'bg-amber-500 text-white animate-pulse'
                        }`}
                      >
                        {h.status === 'Completed' ? '✓' : '•'}
                      </div>
                      <div className="bg-[#f8fbf7] border border-[#d0dfcc] rounded-2xl p-4 flex-1 space-y-1">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                          <h4 className="text-xs font-extrabold text-slate-900">
                            {h.stage}{' '}
                            <span className="text-[10px] font-mono text-slate-400 font-normal">
                              ({h.timestamp})
                            </span>
                          </h4>
                          <span
                            className={`text-[10px] font-mono font-bold ${
                              h.status === 'Completed' ? 'text-emerald-800' : 'text-amber-700'
                            }`}
                          >
                            {h.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 font-medium">
                          {h.location} · <strong className="text-slate-800">{h.handler}</strong>
                        </p>
                        <div className="text-[11px] text-emerald-700 font-semibold pt-1 border-t border-slate-200/60">
                          {h.note}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: QR SCANNER */}
          {currentTab === 'scanner' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-brand-50 text-brand-800 border border-brand-200 mb-2">
                    <ShieldCheck className="w-3.5 h-3.5" /> Universal Mobile QR Engine
                  </div>
                  <h2 className="text-2xl font-extrabold text-slate-900">
                    Produce QR Code Scanner & Audit Console
                  </h2>
                  <p className="text-xs text-slate-500 mt-1">
                    Point your camera at any printed tag or test code to query Firestore across connected phones.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setActiveBatchId('TF-2026-00125');
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition flex items-center gap-1 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 text-brand-800" /> Banana #125
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setActiveBatchId('TF-2026-00127');
                    }}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition flex items-center gap-1 cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 text-brand-800" /> Mangoes #127
                  </button>
                </div>
              </div>

              <QRScannerEngine
                batches={batches}
                onOpenJourney={(id) => {
                  setActiveBatchId(id);
                  setCurrentTab('journey');
                }}
                onOpenStaffModal={() => setIsStaffModalOpen(true)}
                showToast={showToast}
                targetInitialId={activeBatchId}
              />
            </div>
          )}

          {/* TAB 5: APMC REGISTRY */}
          {currentTab === 'registry' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-4 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                  <div>
                    <h2 className="text-2xl font-extrabold text-slate-900">
                      APMC Mandi Ledger Registry
                    </h2>
                    <p className="text-xs text-slate-500">
                      Centralized real-time cloud database of produce batches synchronized across Indian APMC hubs
                    </p>
                  </div>
                  <input
                    type="text"
                    value={registrySearch}
                    onChange={(e) => setRegistrySearch(e.target.value)}
                    placeholder="Search registry..."
                    className="bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:border-brand-800 focus:outline-none w-full sm:w-64"
                  />
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#f8fbf7] text-slate-500 font-mono text-[10px] uppercase border-b border-slate-200">
                      <tr>
                        <th className="px-4 py-3">BATCH ID</th>
                        <th className="px-4 py-3">CROP VARIETY</th>
                        <th className="px-4 py-3">FARM ORIGIN</th>
                        <th className="px-4 py-3">MANDI HUB</th>
                        <th className="px-4 py-3">QUANTITY</th>
                        <th className="px-4 py-3">GRADE</th>
                        <th className="px-4 py-3 text-right">ACTIONS</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {filteredRegistryBatches.map((b) => (
                        <tr key={b.id} className="hover:bg-slate-50 transition">
                          <td className="px-4 py-3 font-mono font-bold text-brand-800">{b.id}</td>
                          <td className="px-4 py-3">
                            <div className="font-extrabold text-slate-900">{b.product}</div>
                            <div className="text-[10px] text-slate-500">{b.variety}</div>
                          </td>
                          <td className="px-4 py-3 text-slate-600">{b.farm}</td>
                          <td className="px-4 py-3 text-slate-600">{b.mandi}</td>
                          <td className="px-4 py-3 font-mono font-bold text-slate-800">
                            {b.quantity}
                          </td>
                          <td className="px-4 py-3">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                                b.grade && b.grade.includes('Grade A')
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {b.grade}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveBatchId(b.id);
                                  setCurrentTab('journey');
                                }}
                                className="text-brand-800 font-bold hover:underline cursor-pointer"
                              >
                                Inspect
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTargetId(b.id)}
                                className="p-1.5 text-red-500 hover:bg-red-50 rounded-lg transition cursor-pointer"
                                title="Delete Batch"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: BUSINESS INSIGHTS */}
          {currentTab === 'eco' && (
            <div className="space-y-8 animate-in fade-in duration-200">
              <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-2 shadow-sm">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-300">
                  <Leaf className="w-3.5 h-3.5" /> Sustainability Metrics
                </div>
                <h2 className="text-2xl font-extrabold text-slate-900">
                  Environmental & Economic Impact Dashboard
                </h2>
                <p className="text-xs text-slate-500">
                  Quantifying food waste reduction and carbon savings through QR traceability.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-3 shadow-sm text-center">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-100 border border-emerald-200 flex items-center justify-center text-emerald-800 mx-auto">
                    <TrendingDown className="w-6 h-6" />
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">28.4%</div>
                  <h4 className="text-xs font-extrabold text-slate-800">Transit Spoilage Reduced</h4>
                  <p className="text-[11px] text-slate-500">
                    Compared to traditional unmonitored APMC mandi routes
                  </p>
                </div>

                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-3 shadow-sm text-center">
                  <div className="w-12 h-12 rounded-2xl bg-brand-100 border border-brand-200 flex items-center justify-center text-brand-800 mx-auto">
                    <CloudRain className="w-6 h-6" />
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">18.1 Tons</div>
                  <h4 className="text-xs font-extrabold text-slate-800">CO₂e Emissions Prevented</h4>
                  <p className="text-[11px] text-slate-500">
                    By eliminating methane emissions from rotten agricultural waste
                  </p>
                </div>

                <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-3 shadow-sm text-center">
                  <div className="w-12 h-12 rounded-2xl bg-teal-100 border border-teal-200 flex items-center justify-center text-teal-800 mx-auto">
                    <Droplet className="w-6 h-6" />
                  </div>
                  <div className="text-3xl font-black text-slate-900 font-mono">4.2M Liters</div>
                  <h4 className="text-xs font-extrabold text-slate-800">Water Saved</h4>
                  <p className="text-[11px] text-slate-500">
                    Virtual irrigation water preserved through crop protection
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Staff & Authentication Modal */}
      <AuthStaffModal
        isOpen={isStaffModalOpen}
        onClose={() => setIsStaffModalOpen(false)}
        showToast={showToast}
      />

      {/* Defect Reporting Modal */}
      <DefectReportModal
        isOpen={isDefectModalOpen}
        onClose={() => setIsDefectModalOpen(false)}
        batches={batches}
        defaultBatchId={activeBatchId}
        onDefectSubmitted={(bId) => {
          setActiveBatchId(bId);
          setCurrentTab('journey');
        }}
        showToast={showToast}
      />

      {/* Delete Confirmation Modal */}
      {deleteTargetId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-[#e2ece0] rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-extrabold text-red-700 text-base flex items-center gap-2">
                <Trash2 className="w-5 h-5" /> Delete Crop Batch
              </h3>
              <button
                type="button"
                onClick={() => setDeleteTargetId(null)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Are you sure you want to delete batch{' '}
              <strong className="font-mono text-slate-900">{deleteTargetId}</strong>? This will
              permanently remove it from the Firestore database across all connected devices.
            </p>

            <div className="pt-2 flex gap-3">
              <button
                type="button"
                onClick={() => setDeleteTargetId(null)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleDeleteBatch}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer"
              >
                Delete Permanently
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Bottom Navigation Bar for Smartphones */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-[#e2ece0] z-40 flex items-center justify-around py-1.5 px-3 safe-area-bottom shadow-lg">
        <button
          type="button"
          onClick={() => {
            setCurrentTab('overview');
            setMobileSidebarOpen(false);
          }}
          className={`flex flex-col items-center justify-center p-1 rounded-xl text-[10px] font-bold transition ${
            currentTab === 'overview' ? 'text-brand-800 font-extrabold' : 'text-slate-500'
          }`}
        >
          <LayoutGrid className="w-5 h-5 mb-0.5" />
          <span>Home</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setCurrentTab('batches');
            setMobileSidebarOpen(false);
          }}
          className={`flex flex-col items-center justify-center p-1 rounded-xl text-[10px] font-bold transition ${
            currentTab === 'batches' ? 'text-brand-800 font-extrabold' : 'text-slate-500'
          }`}
        >
          <Boxes className="w-5 h-5 mb-0.5" />
          <span>Batches</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setCurrentTab('scanner');
            setMobileSidebarOpen(false);
          }}
          className="flex flex-col items-center justify-center -mt-5 bg-brand-800 text-white rounded-2xl p-3 shadow-lg border-2 border-white hover:bg-brand-700 transition cursor-pointer"
          title="Open QR Scanner"
        >
          <QrCode className="w-5 h-5 text-emerald-300" />
        </button>

        <button
          type="button"
          onClick={() => {
            setCurrentTab('journey');
            setMobileSidebarOpen(false);
          }}
          className={`flex flex-col items-center justify-center p-1 rounded-xl text-[10px] font-bold transition ${
            currentTab === 'journey' ? 'text-brand-800 font-extrabold' : 'text-slate-500'
          }`}
        >
          <Truck className="w-5 h-5 mb-0.5" />
          <span>Journey</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setCurrentTab('registry');
            setMobileSidebarOpen(false);
          }}
          className={`flex flex-col items-center justify-center p-1 rounded-xl text-[10px] font-bold transition ${
            currentTab === 'registry' ? 'text-brand-800 font-extrabold' : 'text-slate-500'
          }`}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>APMC</span>
        </button>
      </nav>
    </div>
  );
}
