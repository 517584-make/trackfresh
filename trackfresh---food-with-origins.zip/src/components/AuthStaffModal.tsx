import React from 'react';
import { X, LogIn, LogOut, ShieldCheck, Check, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PRESET_ROLES, UserProfile } from '../types';

interface AuthStaffModalProps {
  isOpen: boolean;
  onClose: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const AuthStaffModal: React.FC<AuthStaffModalProps> = ({
  isOpen,
  onClose,
  showToast
}) => {
  const {
    firebaseUser,
    activeProfile,
    isSigningIn,
    signInWithGoogle,
    signOut,
    switchRoleProfile
  } = useAuth();

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    try {
      await signInWithGoogle();
      showToast('Successfully authenticated with Google!', 'success');
      onClose();
    } catch (err: any) {
      showToast(`Google Sign-in failed: ${err.message || 'Popup closed'}`, 'error');
    }
  };

  const handleRoleSelect = (role: UserProfile) => {
    switchRoleProfile(role);
    showToast(`Switched active role: ${role.displayName} (${role.roleTitle})`, 'success');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#e2ece0] rounded-3xl p-6 max-w-md w-full space-y-5 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-brand-800 text-white flex items-center justify-center">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-900 text-base">User Authentication & Role</h3>
              <p className="text-[10px] text-slate-400 font-mono">Firebase Auth & RBAC Security</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Real Google Auth Section */}
        <div className="p-4 rounded-2xl bg-[#f0f7f2] border border-brand-200 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-brand-900 font-mono">
              GOOGLE ACCOUNT AUTHENTICATION
            </span>
            {firebaseUser && !firebaseUser.isAnonymous ? (
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold font-mono">
                Signed In
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold font-mono">
                Session Auth
              </span>
            )}
          </div>

          {firebaseUser && !firebaseUser.isAnonymous ? (
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 overflow-hidden">
                {firebaseUser.photoURL ? (
                  <img
                    src={firebaseUser.photoURL}
                    alt={firebaseUser.displayName || 'User'}
                    className="w-9 h-9 rounded-xl object-cover border border-emerald-300"
                  />
                ) : (
                  <div className="w-9 h-9 rounded-xl bg-brand-800 text-white font-bold text-xs flex items-center justify-center">
                    {activeProfile.initials}
                  </div>
                )}
                <div className="overflow-hidden">
                  <div className="text-xs font-extrabold text-slate-900 truncate">
                    {firebaseUser.displayName || firebaseUser.email}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-medium truncate">
                    {firebaseUser.email} (Super Admin)
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={signOut}
                className="px-3 py-1.5 bg-white border border-red-200 hover:bg-red-50 text-red-600 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" /> Sign Out
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={isSigningIn}
              onClick={handleGoogleSignIn}
              className="w-full py-2.5 px-4 bg-white hover:bg-slate-50 text-slate-900 border border-[#c2d4bf] font-extrabold rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isSigningIn ? 'Connecting to Google...' : 'Sign In with Google Account'}</span>
            </button>
          )}
        </div>

        {/* APMC Demo Personas Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider font-mono">
              SELECT APMC WORKSPACE PERSONA
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Simulate Handovers</span>
          </div>

          <div className="space-y-2">
            {PRESET_ROLES.map((role) => {
              const isSelected = activeProfile.uid === role.uid;
              return (
                <button
                  key={role.uid}
                  type="button"
                  onClick={() => handleRoleSelect(role)}
                  className={`w-full p-3 rounded-2xl border text-left flex items-center justify-between gap-3 transition cursor-pointer ${
                    isSelected
                      ? 'bg-brand-50 border-brand-300 text-brand-900 font-bold shadow-sm'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-brand-800 text-white font-mono font-black text-xs flex items-center justify-center">
                      {role.initials}
                    </div>
                    <div>
                      <div className="text-xs font-extrabold flex items-center gap-1.5">
                        {role.displayName}
                        {role.canCreate && (
                          <span className="px-1.5 py-0.2 bg-emerald-100 text-emerald-800 text-[9px] rounded font-mono">
                            Admin
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {role.roleTitle} · {role.facility}
                      </div>
                    </div>
                  </div>
                  {isSelected ? (
                    <span className="text-xs font-bold text-brand-800 flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Active
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-400 font-mono">Select</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
        >
          Close Window
        </button>
      </div>
    </div>
  );
};
