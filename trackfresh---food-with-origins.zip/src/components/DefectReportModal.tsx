import React, { useState } from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { BatchItem } from '../types';
import { useAuth } from '../context/AuthContext';
import { logDefectReport } from '../services/batchService';

interface DefectReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  batches: BatchItem[];
  defaultBatchId?: string;
  onDefectSubmitted: (batchId: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DefectReportModal: React.FC<DefectReportModalProps> = ({
  isOpen,
  onClose,
  batches,
  defaultBatchId,
  onDefectSubmitted,
  showToast
}) => {
  const { activeProfile } = useAuth();
  const [selectedBatchId, setSelectedBatchId] = useState<string>(
    defaultBatchId || (batches[0] ? batches[0].id : '')
  );
  const [defectType, setDefectType] = useState<string>('Physical Bruising / Crushing');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    if (!selectedBatchId) {
      showToast('Please select a batch to report defect', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      await logDefectReport(selectedBatchId, defectType, activeProfile);
      showToast(
        `Defect reported for ${selectedBatchId}. Grade downgraded and logged in Firestore!`,
        'error'
      );
      onDefectSubmitted(selectedBatchId);
      onClose();
    } catch (err) {
      showToast('Failed to submit defect report to database', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-[#e2ece0] rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-extrabold text-red-700 text-base flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-600" /> Report Produce Defect
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          Reporting rot, thermal abuse, or spoilage dynamically downgrades batch quality to Grade C, slashes pricing, and publishes an alert directly to Firestore.
        </p>

        <div className="space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Target Batch</label>
            <select
              value={selectedBatchId}
              onChange={(e) => setSelectedBatchId(e.target.value)}
              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs font-mono font-bold focus:border-brand-800 focus:outline-none"
            >
              {batches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.id} — {b.product} ({b.grade})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Observed Defect Type</label>
            <select
              value={defectType}
              onChange={(e) => setDefectType(e.target.value)}
              className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs font-semibold focus:border-brand-800 focus:outline-none"
            >
              <option value="Physical Bruising / Crushing">Physical Bruising / Crushing</option>
              <option value="Fungal Rot / Mold Growth">Fungal Rot / Mold Growth</option>
              <option value="Thermal / Cold-Chain Break Damage">Thermal / Cold-Chain Break Damage</option>
              <option value="Insect Pest Infestation">Insect Pest Infestation</option>
            </select>
          </div>

          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-[11px] text-red-800">
            Reporting Operator: <strong>{activeProfile.displayName}</strong> ({activeProfile.roleTitle})
          </div>
        </div>

        <div className="pt-2 flex gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl text-xs transition cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={isSubmitting}
            onClick={handleSubmit}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-xl text-xs transition shadow-md cursor-pointer"
          >
            {isSubmitting ? 'Publishing...' : 'Submit Defect Report'}
          </button>
        </div>
      </div>
    </div>
  );
};
