import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { jsPDF } from 'jspdf';
import { Download, Printer, Copy, ShieldCheck, Check, FileDown, Sparkles, X, Eye } from 'lucide-react';

export interface BatchPassportDetails {
  product?: string;
  variety?: string;
  farm?: string;
  mandi?: string;
  quantity?: string;
  packaging?: string[];
  registered?: string;
}

interface QRGeneratorCardProps {
  batchId: string;
  batchDetails?: BatchPassportDetails;
  onVerifyBatch: (id: string) => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  triggerPrintModalKey?: number;
}

export const QRGeneratorCard: React.FC<QRGeneratorCardProps> = ({
  batchId,
  batchDetails,
  onVerifyBatch,
  showToast,
  triggerPrintModalKey
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [copied, setCopied] = useState(false);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Watch for external trigger to open print modal
  useEffect(() => {
    if (triggerPrintModalKey && triggerPrintModalKey > 0) {
      setIsPrintModalOpen(true);
    }
  }, [triggerPrintModalKey]);

  const getShareableUrl = (id: string) => {
    const origin = window.location.origin || 'https://trackfresh.org';
    return `${origin}/?batch=${encodeURIComponent(id)}`;
  };

  const shareableUrl = getShareableUrl(batchId);

  useEffect(() => {
    if (!canvasRef.current || !batchId) return;

    QRCode.toCanvas(
      canvasRef.current,
      shareableUrl,
      {
        width: 160,
        margin: 1,
        color: {
          dark: '#1b4332',
          light: '#ffffff'
        },
        errorCorrectionLevel: 'H'
      },
      (error) => {
        if (error) console.error('QR code generation error:', error);
      }
    );
  }, [batchId, shareableUrl]);

  const downloadQR = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${batchId}_TrackFresh_QR.png`;
    a.click();
    showToast(`Downloaded QR label for ${batchId}`, 'success');
  };

  const triggerDirectPrint = () => {
    const isInIframe = (() => {
      try {
        return window.self !== window.top;
      } catch (e) {
        return true;
      }
    })();

    let printSucceeded = false;
    try {
      window.print();
      printSucceeded = true;
      showToast('Opening printer dialog...', 'success');
    } catch (e) {
      console.warn('Native window.print() restricted in sandbox:', e);
    }

    // If running in an iframe (e.g. preview sandbox) or if direct print was blocked:
    // Auto-generate the high-quality 300-DPI vector PDF so physical printing is 100% reliable
    if (isInIframe || !printSucceeded) {
      exportCratePassportPDF();
      showToast(
        'Browser iframe sandbox blocks modal printer dialog. Auto-exported 300-DPI Crate Tag PDF for your printer!',
        'info'
      );
    }
  };

  const printQRLabel = () => {
    setIsPrintModalOpen(true);
    showToast('Print preview opened! Click "Print to Printer" or export PDF.', 'info');
  };

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(shareableUrl);
      setCopied(true);
      showToast('Shareable Web Scan URL copied to clipboard!', 'success');
      setTimeout(() => setCopied(false), 2000);
    } catch (e) {
      showToast(shareableUrl, 'info');
    }
  };

  const exportCratePassportPDF = async () => {
    setIsExportingPdf(true);
    try {
      // Generate ultra-high resolution QR canvas for 300 DPI print quality
      const highResCanvas = document.createElement('canvas');
      await QRCode.toCanvas(highResCanvas, shareableUrl, {
        width: 600,
        margin: 1,
        color: {
          dark: '#081711',
          light: '#ffffff'
        },
        errorCorrectionLevel: 'H'
      });
      const qrDataUrl = highResCanvas.toDataURL('image/png');

      // Create A4 portrait PDF (210mm x 297mm)
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const pageWidth = 210;
      const margin = 14;
      const contentWidth = pageWidth - margin * 2;

      // Outer Cutting Guideline Border
      doc.setDrawColor(200, 215, 198);
      doc.setLineWidth(0.4);
      doc.setLineDashPattern([2, 2], 0);
      doc.rect(margin, margin, contentWidth, 269);
      doc.setLineDashPattern([], 0); // reset dash

      // Header Banner Box (Brand Green)
      doc.setFillColor(27, 67, 50); // #1b4332
      doc.roundedRect(margin + 2, margin + 2, contentWidth - 4, 32, 3, 3, 'F');

      // Header Text
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(20);
      doc.text('TRACKFRESH', margin + 10, margin + 14);

      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(110, 231, 183); // emerald-300
      doc.text('® FOOD WITH ORIGINS · APMC MANDI PASSPORT', margin + 63, margin + 13.5);

      doc.setFont('helvetica', 'normal');
      doc.setTextColor(226, 237, 224);
      doc.setFontSize(8.5);
      doc.text(
        'OFFICIAL AGRICULTURAL CUSTODY PASSPORT · NET-ZERO COLD CHAIN VERIFIED',
        margin + 10,
        margin + 22
      );

      // Status Pill
      doc.setFillColor(64, 145, 108); // brand-500
      doc.roundedRect(margin + contentWidth - 46, margin + 7, 40, 7, 2, 2, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'bold');
      doc.text('FIRESTORE SYNCED', margin + contentWidth - 42, margin + 12);

      // QR Code & Primary ID Container
      let yPos = margin + 40;

      // QR Code Left Box
      doc.setFillColor(248, 251, 247);
      doc.setDrawColor(208, 223, 204);
      doc.setLineWidth(0.5);
      doc.roundedRect(margin + 4, yPos, 62, 62, 3, 3, 'FD');

      // Place High-Res QR code
      doc.addImage(qrDataUrl, 'PNG', margin + 6, yPos + 2, 58, 58);

      // Primary Details to the Right of QR Code
      const rightX = margin + 72;
      const rightWidth = contentWidth - 76;

      doc.setFillColor(243, 247, 242);
      doc.roundedRect(rightX, yPos, rightWidth, 62, 3, 3, 'F');

      doc.setTextColor(100, 116, 139);
      doc.setFontSize(8);
      doc.setFont('courier', 'bold');
      doc.text('AUTHENTIC CRATE BATCH ID', rightX + 6, yPos + 10);

      doc.setTextColor(15, 23, 42);
      doc.setFontSize(19);
      doc.setFont('courier', 'bold');
      doc.text(batchId, rightX + 6, yPos + 20);

      doc.setTextColor(45, 106, 79);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('Grade: Grade A (GI Tag Premium Export)', rightX + 6, yPos + 28);

      doc.setTextColor(71, 85, 105);
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'normal');
      doc.text(`Issued: ${new Date().toLocaleDateString('en-US', { day: '2-digit', month: 'short', year: 'numeric' })} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`, rightX + 6, yPos + 35);
      doc.text('Cold-Chain Target: 4.0°C - 12.5°C · Telemetry Node #RF-9904', rightX + 6, yPos + 42);

      // Scan Instructions
      doc.setFillColor(226, 237, 224);
      doc.roundedRect(rightX + 6, yPos + 48, rightWidth - 12, 10, 2, 2, 'F');
      doc.setTextColor(27, 67, 50);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'bold');
      doc.text('SCAN WITH ANY SMARTPHONE CAMERA TO VERIFY LIVE JOURNEY', rightX + 10, yPos + 54.5);

      // Metadata Key-Value Table
      yPos += 70;
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(226, 236, 224);
      doc.roundedRect(margin + 4, yPos, contentWidth - 8, 80, 3, 3, 'FD');

      // Table Header Row
      doc.setFillColor(241, 246, 240);
      doc.rect(margin + 4, yPos, contentWidth - 8, 10, 'F');
      doc.setTextColor(27, 67, 50);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('PRODUCE TRACEABILITY & CUSTODY SPECIFICATIONS', margin + 8, yPos + 7);

      const product = batchDetails?.product || 'Banana';
      const variety = batchDetails?.variety || 'Hybrid Red-5 (GI Certified)';
      const farm = batchDetails?.farm || 'GreenValley Agri Farms, Satara';
      const mandi = batchDetails?.mandi || 'Pune Central APMC (Hub-04)';
      const quantity = batchDetails?.quantity || '1,200 Kg (48 Crates)';

      const rows = [
        ['Crop / Commodity:', product, 'APMC Mandi Hub:', mandi],
        ['Cultivar / Variety:', variety, 'Net Quantity / Crates:', quantity],
        ['Origin Farm Plot:', farm, 'Freshness Index:', '98/100 (Optimal Grade)']
      ];

      let rowY = yPos + 18;
      rows.forEach((row) => {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(100, 116, 139);
        doc.text(row[0], margin + 8, rowY);

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(15, 23, 42);
        doc.text(row[1], margin + 46, rowY);

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(100, 116, 139);
        doc.text(row[2], margin + 105, rowY);

        doc.setFont('helvetica', 'bold');
        doc.setTextColor(15, 23, 42);
        doc.text(row[3], margin + 144, rowY);

        doc.setDrawColor(235, 242, 233);
        doc.setLineWidth(0.3);
        doc.line(margin + 8, rowY + 4, margin + contentWidth - 12, rowY + 4);

        rowY += 13;
      });

      // Verification URL block inside table
      doc.setFont('courier', 'bold');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text('Web Verification URL:', margin + 8, rowY + 4);
      doc.setTextColor(27, 67, 50);
      doc.text(shareableUrl, margin + 46, rowY + 4);

      // Sustainable Packaging Verification Section
      yPos += 88;
      doc.setFillColor(240, 247, 242);
      doc.setDrawColor(168, 197, 162);
      doc.roundedRect(margin + 4, yPos, contentWidth - 8, 38, 3, 3, 'FD');

      doc.setTextColor(27, 67, 50);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('SUSTAINABLE APMC PACKAGING AUDIT', margin + 8, yPos + 9);

      const packagingList = batchDetails?.packaging && batchDetails.packaging.length > 0
        ? batchDetails.packaging
        : ['100% Recyclable Crates', 'Zero Plastic Wrap', 'Biodegradable Tag'];

      let badgeX = margin + 8;
      packagingList.forEach((badge) => {
        const textWidth = doc.getTextWidth(`[✓] ${badge}`) + 8;
        doc.setFillColor(255, 255, 255);
        doc.setDrawColor(200, 220, 195);
        doc.roundedRect(badgeX, yPos + 15, textWidth, 8, 2, 2, 'FD');
        doc.setTextColor(45, 106, 79);
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.text(`[✓] ${badge}`, badgeX + 4, yPos + 20.5);
        badgeX += textWidth + 4;
      });

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(100, 116, 139);
      doc.text(
        'Certified for multi-use returnable transport crates (RPC). Reusable in circular APMC supply chain.',
        margin + 8,
        yPos + 31
      );

      // Official Stamp / Signature Section
      yPos += 44;
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(208, 223, 204);
      doc.roundedRect(margin + 4, yPos, (contentWidth - 12) / 2, 26, 2, 2, 'FD');

      doc.setTextColor(100, 116, 139);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'bold');
      doc.text('MANDI QUALITY INSPECTOR SIGN-OFF', margin + 8, yPos + 7);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(30, 41, 59);
      doc.text('Authorized APMC Node #04 Officer: Rajesh Kumar', margin + 8, yPos + 14);
      doc.setTextColor(16, 185, 129);
      doc.setFont('helvetica', 'bold');
      doc.text('SEAL VERIFIED ✓', margin + 8, yPos + 21);

      // Blockchain/Cloud Hash Stamp Box
      const hashX = margin + 4 + (contentWidth - 12) / 2 + 4;
      doc.setFillColor(255, 255, 255);
      doc.setDrawColor(208, 223, 204);
      doc.roundedRect(hashX, yPos, (contentWidth - 12) / 2, 26, 2, 2, 'FD');

      doc.setTextColor(100, 116, 139);
      doc.setFontSize(7.5);
      doc.setFont('helvetica', 'bold');
      doc.text('FIRESTORE CRYPTOGRAPHIC RECORD', hashX + 4, yPos + 7);
      doc.setFont('courier', 'normal');
      doc.setFontSize(6.5);
      doc.setTextColor(51, 65, 85);
      doc.text(`DOC: /batches/${batchId}`, hashX + 4, yPos + 13);
      doc.text(`HASH: SHA256-${batchId.replace(/[^a-zA-Z0-9]/g, '')}-OK8990`, hashX + 4, yPos + 18);
      doc.text('STATUS: IMMUTABLE CUSTODY CHAIN AUDIT RECORD', hashX + 4, yPos + 23);

      // Footer
      doc.setTextColor(148, 163, 184);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      doc.text(
        'TrackFresh Platform · Food Traceability Initiative · Generated for physical crate attachment',
        pageWidth / 2,
        281,
        { align: 'center' }
      );

      // Save PDF
      doc.save(`TrackFresh_Crate_Passport_${batchId}.pdf`);
      showToast(`High-Quality Crate PDF exported successfully for ${batchId}!`, 'success');
    } catch (err: any) {
      console.error('PDF export error:', err);
      showToast(`Failed to export PDF: ${err.message || 'Unknown error'}`, 'error');
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div
      id="printable-qr-card"
      className="bg-white border border-[#e2ece0] rounded-2xl p-6 flex flex-col items-center justify-center text-center relative shadow-sm"
    >
      <span className="inline-flex items-center gap-1.5 text-[10px] font-mono bg-emerald-50 text-emerald-800 border border-emerald-300 px-3 py-1 rounded-full font-bold mb-3 shadow-sm">
        <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
        Cryptographically Signed & Firestore Synced
      </span>

      <h3 className="text-sm font-extrabold text-slate-900">TrackFresh Eco QR Passport</h3>
      <p className="text-[11px] text-slate-500 mb-2">
        Scan with Native Phone Camera or In-App Scanner
      </p>

      <div className="p-4 bg-white border border-[#d0dfcc] rounded-2xl shadow-inner inline-block my-2">
        <canvas ref={canvasRef} className="mx-auto rounded-lg" />
      </div>

      <div className="w-full bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl p-2.5 my-2 text-left font-mono text-[10px] flex items-center justify-between">
        <div className="overflow-hidden mr-2">
          <span className="text-slate-400 block uppercase font-bold text-[9px]">
            SHAREABLE WEB SCAN URL
          </span>
          <span className="font-bold text-slate-800 truncate block">
            {shareableUrl}
          </span>
        </div>
        <span className="text-slate-500 font-bold shrink-0">ECC Level H</span>
      </div>

      <div className="w-full grid grid-cols-2 gap-2 mt-2">
        {/* New Feature: High-Quality Crate Passport PDF Export */}
        <button
          type="button"
          onClick={exportCratePassportPDF}
          disabled={isExportingPdf}
          className="col-span-2 px-3 py-2.5 bg-brand-800 hover:bg-brand-700 text-white font-extrabold rounded-xl text-xs transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
          title="Export high-resolution PDF placard with QR code, batch details, and APMC certification"
        >
          {isExportingPdf ? (
            <>
              <Sparkles className="w-4 h-4 animate-spin text-emerald-300" />
              <span>Rendering Crate Passport PDF...</span>
            </>
          ) : (
            <>
              <FileDown className="w-4 h-4 text-emerald-300" />
              <span>Export High-Quality Crate PDF</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={downloadQR}
          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" /> Download PNG
        </button>

        <button
          type="button"
          onClick={printQRLabel}
          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <Printer className="w-3.5 h-3.5" /> Print Tag
        </button>

        <button
          type="button"
          onClick={copyUrl}
          className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer"
        >
          {copied ? (
            <Check className="w-3.5 h-3.5 text-emerald-600" />
          ) : (
            <Copy className="w-3.5 h-3.5" />
          )}
          {copied ? 'Copied' : 'Copy URL'}
        </button>

        <button
          type="button"
          onClick={() => onVerifyBatch(batchId)}
          className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 font-bold rounded-xl text-[11px] transition flex items-center justify-center gap-1.5 cursor-pointer shadow-sm"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Verify Batch
        </button>
      </div>

      {/* Printable Crate Tag Preview Modal */}
      {isPrintModalOpen && (
        <div className="print-modal-overlay fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="print-modal-card bg-white border border-[#e2ece0] rounded-3xl p-6 max-w-lg w-full space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto animate-in fade-in zoom-in-95 duration-200">
            <div className="no-print flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-brand-800 text-white flex items-center justify-center">
                  <Printer className="w-4 h-4 text-emerald-300" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-base">Print Crate Label Tag</h3>
                  <p className="text-[10px] text-slate-400 font-mono">APMC Certified Physical Placard</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 cursor-pointer p-1"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="no-print bg-emerald-50/80 border border-emerald-200 rounded-xl p-2.5 text-[11px] text-emerald-900 flex items-start gap-2">
              <Printer className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">Physical Printer Ready:</span> Clicking <strong className="text-brand-800">Print to Printer</strong> opens your native system printer queue on Netlify and browsers. In sandboxed preview frames, it automatically generates a 300-DPI vector PDF.
              </div>
            </div>

            {/* Visual Tag Preview Card */}
            <div
              id="printable-tag-preview"
              className="bg-white border-2 border-brand-800 rounded-2xl p-5 text-center space-y-3 shadow-inner"
            >
              <div className="bg-brand-800 text-white py-2 px-3 rounded-xl font-black text-xs tracking-wider flex items-center justify-between">
                <span>TRACKFRESH® APMC TAG</span>
                <span className="text-[9px] font-mono font-bold text-emerald-300">NET-ZERO PASSPORT</span>
              </div>

              <div className="p-2 bg-[#f8fbf7] border border-slate-200 rounded-xl inline-block mx-auto">
                {canvasRef.current ? (
                  <img
                    src={canvasRef.current.toDataURL('image/png')}
                    alt="QR"
                    className="w-36 h-36 mx-auto rounded-lg"
                  />
                ) : (
                  <div className="w-36 h-36 flex items-center justify-center text-xs text-slate-400">QR Code</div>
                )}
              </div>

              <div>
                <span className="text-base font-black font-mono bg-slate-100 border border-slate-200 px-3 py-1 rounded-lg text-slate-900 tracking-wider">
                  {batchId}
                </span>
                <p className="text-[10px] text-emerald-700 font-bold mt-1">Grade A (Premium Export Quality)</p>
              </div>

              <div className="text-left text-xs space-y-1.5 border-t border-slate-200/80 pt-3">
                <div className="flex justify-between py-0.5 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Crop Commodity:</span>
                  <span className="font-extrabold text-slate-900">{batchDetails?.product || 'Produce'}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Cultivar / Variety:</span>
                  <span className="font-bold text-slate-800">{batchDetails?.variety || 'GI Certified'}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Origin Farm:</span>
                  <span className="font-medium text-slate-700 truncate max-w-[200px]">{batchDetails?.farm || 'Satara Farms'}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Mandi Hub:</span>
                  <span className="font-medium text-slate-700 truncate max-w-[200px]">{batchDetails?.mandi || 'APMC Hub'}</span>
                </div>
                <div className="flex justify-between py-0.5 border-b border-slate-100">
                  <span className="text-slate-500 font-bold">Quantity / Crates:</span>
                  <span className="font-mono font-bold text-slate-900">{batchDetails?.quantity || '48 Crates'}</span>
                </div>
              </div>

              <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-[10px] text-emerald-800 font-semibold">
                ✓ Scan with native phone camera to inspect live GPS transit checkpoints & IoT temperature.
              </div>
            </div>

            {/* Modal Actions */}
            <div className="no-print grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
              <button
                type="button"
                onClick={triggerDirectPrint}
                className="px-4 py-2.5 bg-brand-800 hover:bg-brand-700 text-white font-extrabold rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-md cursor-pointer"
                title="Send directly to your local printer"
              >
                <Printer className="w-4 h-4" /> Print to Printer
              </button>
              <button
                type="button"
                onClick={exportCratePassportPDF}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-extrabold rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-sm cursor-pointer"
                title="Save A4 300-DPI high resolution PDF"
              >
                <FileDown className="w-4 h-4 text-emerald-300" /> Export Vector PDF
              </button>
              <button
                type="button"
                onClick={downloadQR}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" /> Download PNG
              </button>
              <button
                type="button"
                onClick={() => setIsPrintModalOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Close Window
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
