import React, { useState, useEffect, useRef } from 'react';
import jsQR from 'jsqr';
import { Camera, Video, Play, Navigation, Keyboard, ShieldCheck, CheckCircle2, UserCheck, ExternalLink } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { BatchItem } from '../types';
import { saveBatchToFirestore } from '../services/batchService';

interface QRScannerEngineProps {
  batches: BatchItem[];
  onOpenJourney: (batchId: string) => void;
  onOpenStaffModal: () => void;
  showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  targetInitialId?: string;
}

export const QRScannerEngine: React.FC<QRScannerEngineProps> = ({
  batches,
  onOpenJourney,
  onOpenStaffModal,
  showToast,
  targetInitialId
}) => {
  const { activeProfile } = useAuth();
  const [manualInput, setManualInput] = useState<string>(targetInitialId || 'TF-2026-00125');
  const [isWebcamActive, setIsWebcamActive] = useState<boolean>(false);
  const [auditProgress, setAuditProgress] = useState<number>(0);
  const [auditStatus, setAuditStatus] = useState<'READY' | 'AUDITING' | 'VERIFIED' | 'NOT_FOUND'>('READY');
  const [stepStates, setStepStates] = useState<Array<'pending' | 'evaluating' | 'passed'>>([
    'pending',
    'pending',
    'pending',
    'pending'
  ]);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const timerRef = useRef<any>(null);

  // Helper to extract batch ID from scanned string or full URL
  const extractBatchId = (raw: string): string => {
    if (!raw) return 'TF-2026-00125';
    const clean = raw.trim();

    try {
      if (clean.includes('http://') || clean.includes('https://') || clean.includes('?')) {
        const url = new URL(clean, window.location.origin);
        const batchParam = url.searchParams.get('batch') || url.searchParams.get('id') || url.searchParams.get('code');
        if (batchParam) return batchParam.toUpperCase();
      }
    } catch (e) {
      // not a url
    }

    const match = clean.match(/(TF-\d{4}-\d{5})/i) || clean.match(/(TF-[A-Za-z0-9_-]+)/i);
    if (match) return match[1].toUpperCase();

    return clean.replace('trackfresh://', '').toUpperCase();
  };

  const toggleWebcam = async () => {
    if (isWebcamActive) {
      stopWebcam();
      showToast('Camera feed stopped', 'info');
      return;
    }

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        showToast('Camera not accessible in this environment. Use manual input or test buttons.', 'info');
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsWebcamActive(true);
      showToast('WebCam active! Scanning frames for QR codes...', 'success');
      scanVideoFrames();
    } catch (err) {
      showToast('Camera permission denied or camera device busy', 'error');
    }
  };

  const scanVideoFrames = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        });

        if (code && code.data) {
          const detectedId = extractBatchId(code.data);
          stopWebcam();
          setManualInput(detectedId);
          showToast(`Decoded QR: ${detectedId}`, 'success');
          triggerAudit(detectedId);
          return;
        }
      }
    }

    animationFrameRef.current = requestAnimationFrame(scanVideoFrames);
  };

  const stopWebcam = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsWebcamActive(false);
  };

  useEffect(() => {
    return () => {
      stopWebcam();
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const triggerAudit = (targetBatchId?: string) => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    const cleanId = extractBatchId(targetBatchId || manualInput);
    const batch = batches.find((b) => b.id.toUpperCase() === cleanId.toUpperCase());

    if (!batch) {
      setAuditStatus('NOT_FOUND');
      showToast(`Batch ${cleanId} not found in Firestore ledger`, 'error');
      return;
    }

    setAuditStatus('AUDITING');
    setAuditProgress(0);
    setStepStates(['evaluating', 'pending', 'pending', 'pending']);

    let step = 0;
    timerRef.current = setInterval(() => {
      step++;
      const pct = step * 25;
      setAuditProgress(pct);

      if (step === 1) {
        setStepStates(['passed', 'evaluating', 'pending', 'pending']);
      } else if (step === 2) {
        setStepStates(['passed', 'passed', 'evaluating', 'pending']);
      } else if (step === 3) {
        setStepStates(['passed', 'passed', 'passed', 'evaluating']);
      } else if (step === 4) {
        setStepStates(['passed', 'passed', 'passed', 'passed']);
        clearInterval(timerRef.current);
        timerRef.current = null;
        setAuditStatus('VERIFIED');

        // Log custody update in Firestore
        finalizeVerification(batch);
      }
    }, 280);
  };

  const finalizeVerification = async (batch: BatchItem) => {
    const nowStr = new Date().toLocaleString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });

    const targetStageIndex = activeProfile.stageIndex;
    const history = [...(batch.history || [])];

    // Mark previous stages as completed and update current
    for (let i = 0; i <= targetStageIndex; i++) {
      if (history[i]) {
        history[i] = {
          ...history[i],
          status: 'Completed',
          timestamp: nowStr,
          handler: `${activeProfile.displayName} (${activeProfile.roleTitle})`,
          note: `Verified & Scanned via ${activeProfile.facility} ✓`
        };
      }
    }

    const updatedRoute = [...(batch.route || [])];
    const lastPoint = updatedRoute[updatedRoute.length - 1] || { lat: 18.5204, lng: 73.8567 };

    // Get real device coordinates or approximate node offset
    let lat = lastPoint.lat + (Math.random() * 0.03 - 0.015);
    let lng = lastPoint.lng + (Math.random() * 0.03 - 0.015);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          lat = pos.coords.latitude;
          lng = pos.coords.longitude;
          saveAndRedirect();
        },
        () => {
          saveAndRedirect();
        },
        { timeout: 1500 }
      );
    } else {
      saveAndRedirect();
    }

    async function saveAndRedirect() {
      updatedRoute.push({
        name: `${activeProfile.facility} (${activeProfile.roleTitle} Handover)`,
        lat,
        lng
      });

      const updatedBatch: BatchItem = {
        ...batch,
        history,
        route: updatedRoute,
        updatedAt: new Date().toISOString()
      };

      try {
        await saveBatchToFirestore(updatedBatch, activeProfile);
        showToast(`Batch ${batch.id} authenticated & saved to Firestore!`, 'success');
        setTimeout(() => {
          onOpenJourney(batch.id);
        }, 600);
      } catch (err) {
        showToast('Error persisting handover to cloud database', 'error');
      }
    }
  };

  const tagGPSManually = () => {
    const current = batches.find((b) => b.id === manualInput) || batches[0];
    if (current) {
      finalizeVerification(current);
      showToast('GPS Waypoint recorded and pushed to Cloud!', 'success');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Viewfinder Column */}
      <div className="lg:col-span-6 space-y-6">
        <div className="bg-white border border-[#e2ece0] rounded-2xl p-4 sm:p-6 space-y-4 shadow-sm">
          <div className="relative bg-slate-900 rounded-2xl aspect-square max-w-[380px] mx-auto overflow-hidden flex flex-col items-center justify-center border-4 border-slate-800 shadow-inner">
            <video
              ref={videoRef}
              playsInline
              muted
              className={`absolute inset-0 w-full h-full object-cover z-0 ${!isWebcamActive ? 'hidden' : ''}`}
            />
            <canvas ref={canvasRef} className="hidden" />

            <div className="absolute inset-0 scan-line z-20 pointer-events-none" />

            <div
              className={`w-44 h-44 sm:w-56 sm:h-56 border-2 border-dashed border-emerald-400 rounded-2xl relative z-20 flex items-center justify-center pointer-events-none transition-opacity duration-300 ${
                isWebcamActive ? 'opacity-40' : 'opacity-100'
              }`}
            >
              <div className="text-center space-y-2 p-3 sm:p-4">
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-slate-800/80 text-emerald-400 flex items-center justify-center mx-auto backdrop-blur">
                  <Camera className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <div className="text-white text-[11px] sm:text-xs font-bold font-mono">
                  {isWebcamActive ? 'Live Decoder Active' : 'Universal Mobile Scanner Ready'}
                </div>
                <p className="text-[9px] sm:text-[10px] text-slate-400 font-sans">
                  Point camera at any printed TrackFresh QR tag
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap justify-center pt-2">
            <button
              type="button"
              onClick={toggleWebcam}
              className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold rounded-xl text-xs transition flex items-center gap-2 shadow-lg cursor-pointer"
            >
              <Video className="w-4 h-4" />
              <span>{isWebcamActive ? 'Disable WebCam' : 'Enable WebCam'}</span>
            </button>

            <button
              type="button"
              onClick={() => triggerAudit()}
              className="px-3.5 py-2 bg-brand-800 hover:bg-brand-700 text-white font-extrabold rounded-xl text-xs transition flex items-center gap-1.5 shadow-md cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" /> Run Audit
            </button>

            <button
              type="button"
              onClick={tagGPSManually}
              className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-extrabold rounded-xl text-xs transition flex items-center gap-1.5 cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5 text-emerald-600" /> Tag GPS
            </button>
          </div>

          <div className="bg-[#f8fbf7] border border-[#d0dfcc] rounded-2xl p-4 space-y-2">
            <label className="block text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Keyboard className="w-4 h-4 text-brand-800" /> Manual Batch ID or Scanned URL
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value.toUpperCase())}
                placeholder="TF-2026-00125"
                className="flex-1 bg-white border border-[#d0dfcc] rounded-xl px-3 py-2 text-xs font-mono font-bold focus:border-brand-800 focus:outline-none uppercase"
              />
              <button
                type="button"
                onClick={() => triggerAudit()}
                className="px-5 py-2 bg-brand-800 hover:bg-brand-700 text-white font-extrabold rounded-xl text-xs transition shadow-md cursor-pointer"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Console Column */}
      <div className="lg:col-span-6 space-y-6">
        <div className="bg-white border border-[#e2ece0] rounded-2xl p-6 space-y-5 shadow-sm h-full flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base">Verification Console</h3>
                <p className="text-xs text-slate-500">Firestore Cross-Device Database Lookup</p>
              </div>
              <span
                className={`px-3 py-1 text-[10px] font-mono font-bold rounded-full border transition-all duration-300 ${
                  auditStatus === 'READY'
                    ? 'bg-slate-100 text-slate-700 border-slate-200'
                    : auditStatus === 'AUDITING'
                    ? 'bg-amber-100 text-amber-800 border-amber-300 animate-pulse'
                    : auditStatus === 'VERIFIED'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : 'bg-red-100 text-red-800 border-red-300'
                }`}
              >
                {auditStatus === 'READY'
                  ? 'READY TO SCAN'
                  : auditStatus === 'AUDITING'
                  ? 'AUDITING IN CLOUD...'
                  : auditStatus === 'VERIFIED'
                  ? 'VERIFIED ✓'
                  : 'NOT FOUND'}
              </span>
            </div>

            {/* Progress Bar */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px] font-mono font-bold text-slate-500">
                <span>AUDIT PROGRESS</span>
                <span>{auditProgress}%</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-full transition-all duration-300"
                  style={{ width: `${auditProgress}%` }}
                />
              </div>
            </div>

            {/* Steps Container */}
            <div className="space-y-2.5">
              {[
                'Cryptographic Payload Extraction',
                'APMC Cloud Firestore Batch Query',
                'Farm Geotag & Device GPS Verification',
                'IoT Cold-Chain Telemetry Check'
              ].map((title, idx) => {
                const state = stepStates[idx];
                return (
                  <div
                    key={title}
                    className={`p-3.5 rounded-xl border flex items-center justify-between transition-all duration-300 ${
                      state === 'passed'
                        ? 'bg-emerald-50/80 border-emerald-200 opacity-100'
                        : state === 'evaluating'
                        ? 'bg-amber-50 border-amber-300 opacity-100 animate-pulse'
                        : 'bg-slate-50 border-slate-200 opacity-60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-6 h-6 rounded-lg text-xs font-bold font-mono flex items-center justify-center ${
                          state === 'passed'
                            ? 'bg-brand-800 text-white'
                            : state === 'evaluating'
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-300 text-slate-700'
                        }`}
                      >
                        {state === 'passed' ? '✓' : idx + 1}
                      </div>
                      <span className="text-xs font-bold text-slate-800">{title}</span>
                    </div>

                    <span
                      className={`text-xs font-bold font-mono ${
                        state === 'passed'
                          ? 'text-emerald-800'
                          : state === 'evaluating'
                          ? 'text-amber-700'
                          : 'text-slate-400'
                      }`}
                    >
                      {state === 'passed' ? 'PASSED ✓' : state === 'evaluating' ? 'CHECKING...' : 'PENDING'}
                    </span>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => onOpenJourney(manualInput)}
              className="w-full bg-brand-800 hover:bg-brand-700 text-white font-extrabold py-3 rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-md cursor-pointer"
            >
              <ExternalLink className="w-4 h-4" /> Open Produce Journey Dashboard
            </button>
          </div>

          <div className="p-3 bg-[#f8fbf7] border border-[#d0dfcc] rounded-xl text-xs font-medium text-slate-600 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-brand-800" />
              <span>
                Scanning Identity:{' '}
                <strong className="text-slate-900">
                  {activeProfile.displayName} ({activeProfile.roleTitle})
                </strong>
              </span>
            </span>
            <button
              type="button"
              onClick={onOpenStaffModal}
              className="text-brand-800 font-bold hover:underline cursor-pointer"
            >
              Change
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
