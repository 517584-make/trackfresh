import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { RouteWaypoint } from '../types';

interface TransitMapProps {
  waypoints: RouteWaypoint[];
  activeBatchId: string;
}

export const TransitMap: React.FC<TransitMapProps> = ({ waypoints }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const polylineRef = useRef<L.Polyline | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialLat = waypoints.length > 0 ? waypoints[0].lat : 18.5204;
      const initialLng = waypoints.length > 0 ? waypoints[0].lng : 73.8567;

      const map = L.map(mapContainerRef.current, {
        zoomControl: true,
        scrollWheelZoom: false
      }).setView([initialLat, initialLng], 8);

      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 18,
        attribution: 'Tiles © Esri'
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Invalidate size to guarantee no grey tiles
    setTimeout(() => {
      map.invalidateSize();
    }, 100);

    // Clear existing markers
    markersRef.current.forEach(m => map.removeLayer(m));
    markersRef.current = [];

    if (polylineRef.current) {
      map.removeLayer(polylineRef.current);
      polylineRef.current = null;
    }

    if (waypoints && waypoints.length > 0) {
      const latLngs: [number, number][] = [];

      waypoints.forEach((pt, index) => {
        latLngs.push([pt.lat, pt.lng]);

        // Custom icon styling
        const isFirst = index === 0;
        const isLast = index === waypoints.length - 1;
        const markerColor = isFirst ? '#15803d' : isLast ? '#0284c7' : '#1b4332';

        const customIcon = L.divIcon({
          className: 'custom-map-pin',
          html: `
            <div style="background-color: ${markerColor}; color: white; width: 26px; height: 26px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 11px; border: 2px solid white; box-shadow: 0 2px 6px rgba(0,0,0,0.3); font-family: monospace;">
              ${index + 1}
            </div>
          `,
          iconSize: [26, 26],
          iconAnchor: [13, 13]
        });

        const marker = L.marker([pt.lat, pt.lng], { icon: customIcon }).addTo(map);
        marker.bindPopup(`
          <div style="padding: 4px; font-family: sans-serif;">
            <strong style="color: #0f172a; font-size: 12px;">${index + 1}. ${pt.name}</strong>
            <div style="font-family: monospace; font-size: 10px; color: #64748b; margin-top: 2px;">
              Lat: ${pt.lat.toFixed(4)}°, Lng: ${pt.lng.toFixed(4)}°
            </div>
          </div>
        `);
        markersRef.current.push(marker);
      });

      const polyline = L.polyline(latLngs, {
        color: '#1b4332',
        weight: 3.5,
        opacity: 0.85,
        dashArray: '6, 6'
      }).addTo(map);

      polylineRef.current = polyline;

      try {
        map.fitBounds(polyline.getBounds(), { padding: [35, 35] });
      } catch (e) {
        // bounds catch
      }
    }

    const handleResize = () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    };
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, [waypoints]);

  return (
    <div
      ref={mapContainerRef}
      className="w-full h-64 sm:h-80 rounded-2xl border border-slate-200 shadow-inner overflow-hidden z-0 touch-pan-y"
    />
  );
};
