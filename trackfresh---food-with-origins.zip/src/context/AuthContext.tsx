import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, signInWithPopup, signOut as fbSignOut, onAuthStateChanged, signInAnonymously } from 'firebase/auth';
import { auth, googleProvider, testConnection } from '../firebase/config';
import { PRESET_ROLES, UserProfile } from '../types';
import { fetchUserProfileFromFirestore, saveUserProfileToFirestore } from '../services/batchService';

interface AuthContextType {
  firebaseUser: User | null;
  activeProfile: UserProfile;
  isAuthReady: boolean;
  isCloudSynced: boolean;
  isSigningIn: boolean;
  signInWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  switchRoleProfile: (profile: UserProfile) => void;
  updateActiveFacility: (facility: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [activeProfile, setActiveProfile] = useState<UserProfile>(PRESET_ROLES[0]);
  const [isAuthReady, setIsAuthReady] = useState<boolean>(false);
  const [isCloudSynced, setIsCloudSynced] = useState<boolean>(true);
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);

  useEffect(() => {
    // Test Firestore connection on boot
    testConnection().then((connected) => {
      setIsCloudSynced(connected);
    });

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      if (user) {
        try {
          const remoteProfile = await fetchUserProfileFromFirestore(user.uid);
          if (remoteProfile) {
            setActiveProfile(remoteProfile);
          } else {
            // New authenticated user: check if email is admin or create profile
            const isUserAdmin = user.email === 'ekanshguptta@gmail.com' || (user.email && user.email.includes('admin'));
            const initials = user.displayName
              ? user.displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
              : (user.email ? user.email.slice(0, 2).toUpperCase() : 'US');

            const newProfile: UserProfile = {
              uid: user.uid,
              displayName: user.displayName || user.email?.split('@')[0] || 'Authenticated User',
              email: user.email || '',
              photoURL: user.photoURL || undefined,
              role: isUserAdmin ? 'mandi_admin' : 'citizen',
              roleTitle: isUserAdmin ? 'Mandi Super Admin' : 'Verified Food Inspector',
              facility: isUserAdmin ? 'APMC Central Command Hub' : 'Citizen Mobile App',
              initials,
              canCreate: isUserAdmin ? true : false,
              stageIndex: isUserAdmin ? 1 : 4
            };

            setActiveProfile(newProfile);
            await saveUserProfileToFirestore(newProfile);
          }
        } catch (e) {
          console.warn('Could not load user profile from Firestore:', e);
        }
      } else {
        // Fallback: Sign in anonymously to guarantee valid Firebase Auth token for Firestore security rules
        signInAnonymously(auth).catch((err) => {
          console.log('Anonymous sign in note:', err.message);
        });
      }
      setIsAuthReady(true);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    setIsSigningIn(true);
    try {
      const cred = await signInWithPopup(auth, googleProvider);
      const user = cred.user;
      const isUserAdmin = user.email === 'ekanshguptta@gmail.com' || (user.email && user.email.includes('admin'));
      const initials = user.displayName
        ? user.displayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
        : 'US';

      const userProfile: UserProfile = {
        uid: user.uid,
        displayName: user.displayName || user.email?.split('@')[0] || 'Google User',
        email: user.email || '',
        photoURL: user.photoURL || undefined,
        role: isUserAdmin ? 'mandi_admin' : 'mandi_admin', // Empower authenticated user
        roleTitle: isUserAdmin ? 'Mandi Super Admin (Verified)' : 'APMC Certified Administrator',
        facility: 'APMC Regional Hub Node',
        initials,
        canCreate: true,
        stageIndex: 1
      };

      setActiveProfile(userProfile);
      await saveUserProfileToFirestore(userProfile);
      setIsCloudSynced(true);
    } catch (err) {
      console.error('Google Sign In Error:', err);
      throw err;
    } finally {
      setIsSigningIn(false);
    }
  };

  const signOut = async () => {
    try {
      await fbSignOut(auth);
      setFirebaseUser(null);
      setActiveProfile(PRESET_ROLES[0]);
    } catch (err) {
      console.error('Sign Out Error:', err);
    }
  };

  const switchRoleProfile = (profile: UserProfile) => {
    setActiveProfile(profile);
  };

  const updateActiveFacility = (facility: string) => {
    setActiveProfile(prev => ({ ...prev, facility }));
  };

  return (
    <AuthContext.Provider
      value={{
        firebaseUser,
        activeProfile,
        isAuthReady,
        isCloudSynced,
        isSigningIn,
        signInWithGoogle,
        signOut,
        switchRoleProfile,
        updateActiveFacility
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
