import {
  collection,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  onSnapshot,
  Unsubscribe
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase/config';
import { BatchItem, DEFAULT_BATCHES, DefectReport, UserProfile } from '../types';

const BATCHES_COLLECTION = 'batches';
const USERS_COLLECTION = 'users';
const DEFECTS_COLLECTION = 'defects';

/**
 * Real-time listener for all produce batches in Firestore.
 * Automatically seeds default verified APMC batches if the database is initially empty.
 */
export function subscribeToBatches(
  onSuccess: (batches: BatchItem[]) => void,
  onError?: (err: Error) => void
): Unsubscribe {
  const colRef = collection(db, BATCHES_COLLECTION);

  return onSnapshot(
    colRef,
    async (snapshot) => {
      try {
        if (snapshot.empty) {
          console.log('Seeding initial verified APMC batches to Firestore...');
          await seedDefaultBatches();
          return;
        }

        const batches: BatchItem[] = [];
        snapshot.forEach((docSnap) => {
          batches.push(docSnap.data() as BatchItem);
        });

        onSuccess(batches);
      } catch (err) {
        console.error('Error processing batch snapshot:', err);
      }
    },
    (error) => {
      console.error('Firestore batches listener error:', error);
      if (onError) onError(error);
      try {
        handleFirestoreError(error, OperationType.LIST, BATCHES_COLLECTION);
      } catch (e) {
        // Logged
      }
    }
  );
}

/**
 * Seed initial batches into Firestore
 */
export async function seedDefaultBatches(): Promise<void> {
  for (const batch of DEFAULT_BATCHES) {
    try {
      const docRef = doc(db, BATCHES_COLLECTION, batch.id);
      await setDoc(docRef, batch, { merge: true });
    } catch (error) {
      console.warn('Seeding batch failed:', batch.id, error);
    }
  }
}

/**
 * Fetch a single batch by ID from Firestore
 */
export async function fetchBatchById(batchId: string): Promise<BatchItem | null> {
  const path = `${BATCHES_COLLECTION}/${batchId}`;
  try {
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as BatchItem;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

/**
 * Save or update a produce batch in Firestore
 */
export async function saveBatchToFirestore(
  batch: BatchItem,
  user?: UserProfile
): Promise<void> {
  const path = `${BATCHES_COLLECTION}/${batch.id}`;
  try {
    const docRef = doc(db, BATCHES_COLLECTION, batch.id);
    const payload: BatchItem = {
      ...batch,
      updatedAt: new Date().toISOString(),
      ...(user ? { createdByUid: user.uid, createdByName: `${user.displayName} (${user.roleTitle})` } : {})
    };
    await setDoc(docRef, payload, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Delete a produce batch from Firestore
 */
export async function deleteBatchFromFirestore(batchId: string): Promise<void> {
  const path = `${BATCHES_COLLECTION}/${batchId}`;
  try {
    const docRef = doc(db, BATCHES_COLLECTION, batchId);
    await deleteDoc(docRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

/**
 * Submit a Defect Report and dynamically slash produce grade/price
 */
export async function logDefectReport(
  batchId: string,
  defectType: string,
  user: UserProfile
): Promise<DefectReport> {
  const defectId = `DEF-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  const path = `${DEFECTS_COLLECTION}/${defectId}`;

  const defect: DefectReport = {
    id: defectId,
    batchId,
    defectType,
    reportedBy: `${user.displayName} (${user.roleTitle})`,
    reportedByUid: user.uid,
    timestamp: new Date().toLocaleString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    })
  };

  try {
    const defectDoc = doc(db, DEFECTS_COLLECTION, defectId);
    await setDoc(defectDoc, defect);

    // Fetch and downgrade the targeted batch in Firestore
    const batchSnap = await getDoc(doc(db, BATCHES_COLLECTION, batchId));
    if (batchSnap.exists()) {
      const bData = batchSnap.data() as BatchItem;
      const history = bData.history || [];
      history.push({
        stage: 'Citizen Defect Watchdog Log',
        location: user.facility,
        handler: `${user.displayName} (${user.roleTitle})`,
        timestamp: defect.timestamp,
        status: 'Completed',
        note: `Defect Reported: ${defectType} (Batch downgraded to Grade C).`
      });

      const updatedBatch: Partial<BatchItem> = {
        grade: 'Grade C (Defect Slashed)',
        price: '₹22 / kg',
        freshnessScore: 42,
        condition: 'Defect Alert Raised',
        history,
        updatedAt: new Date().toISOString()
      };

      await setDoc(doc(db, BATCHES_COLLECTION, batchId), updatedBatch, { merge: true });
    }

    return defect;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

/**
 * Save user profile to Firestore
 */
export async function saveUserProfileToFirestore(profile: UserProfile): Promise<void> {
  const path = `${USERS_COLLECTION}/${profile.uid}`;
  try {
    const userDoc = doc(db, USERS_COLLECTION, profile.uid);
    await setDoc(userDoc, {
      uid: profile.uid,
      displayName: profile.displayName,
      email: profile.email,
      role: profile.role,
      roleTitle: profile.roleTitle,
      facility: profile.facility,
      initials: profile.initials,
      photoURL: profile.photoURL || '',
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Retrieve user profile from Firestore
 */
export async function fetchUserProfileFromFirestore(uid: string): Promise<UserProfile | null> {
  const path = `${USERS_COLLECTION}/${uid}`;
  try {
    const userDoc = doc(db, USERS_COLLECTION, uid);
    const snap = await getDoc(userDoc);
    if (snap.exists()) {
      const data = snap.data();
      return {
        uid: data.uid,
        displayName: data.displayName || 'APMC Staff',
        email: data.email || '',
        role: data.role || 'mandi_admin',
        roleTitle: data.roleTitle || 'Mandi Administrator',
        facility: data.facility || 'APMC Node',
        initials: data.initials || 'AP',
        canCreate: data.role === 'mandi_admin',
        stageIndex: data.stageIndex ?? 1,
        photoURL: data.photoURL
      };
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}
