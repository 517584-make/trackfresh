export type UserRole = 'mandi_admin' | 'driver' | 'retailer' | 'citizen';

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  role: UserRole;
  roleTitle: string;
  facility: string;
  initials: string;
  canCreate: boolean;
  stageIndex: number;
}

export interface RouteWaypoint {
  name: string;
  lat: number;
  lng: number;
}

export interface CustodyStep {
  stage: string;
  location: string;
  handler: string;
  timestamp: string;
  status: 'Completed' | 'In Progress' | 'Pending';
  note: string;
}

export interface BatchItem {
  id: string;
  product: string;
  variety: string;
  farm: string;
  mandi: string;
  quantity: string;
  grade: string;
  registered: string;
  condition: string;
  freshnessScore: number;
  temp: string;
  price: string;
  route: RouteWaypoint[];
  history: CustodyStep[];
  createdByUid?: string;
  createdByName?: string;
  createdAt?: string;
  updatedAt?: string;
  packaging?: string[];
}

export interface DefectReport {
  id: string;
  batchId: string;
  defectType: string;
  reportedBy: string;
  reportedByUid: string;
  timestamp: string;
}

export const PRESET_ROLES: UserProfile[] = [
  {
    uid: 'role_mandi_admin_rajesh',
    displayName: 'Rajesh Kumar',
    email: 'rajesh.kumar@apmc.pune.gov.in',
    role: 'mandi_admin',
    roleTitle: 'Mandi Administrator',
    facility: 'Pune Central APMC (Hub-04)',
    initials: 'RK',
    canCreate: true,
    stageIndex: 1
  },
  {
    uid: 'role_driver_suresh',
    displayName: 'Suresh Patil',
    email: 'suresh.patil@reeferlogistics.in',
    role: 'driver',
    roleTitle: 'Reefer Logistics Driver',
    facility: 'Reefer Express #MH-12-VT-8890',
    initials: 'SP',
    canCreate: false,
    stageIndex: 2
  },
  {
    uid: 'role_retailer_anita',
    displayName: 'Anita Sharma',
    email: 'anita.sharma@freshbazaar.com',
    role: 'retailer',
    roleTitle: 'Retail Store Manager',
    facility: 'FreshBazaar Store #104',
    initials: 'AS',
    canCreate: false,
    stageIndex: 3
  },
  {
    uid: 'role_citizen_user',
    displayName: 'Citizen Customer',
    email: 'shopper@consumer.in',
    role: 'citizen',
    roleTitle: 'Consumer / Inspector',
    facility: 'Consumer Mobile Hub',
    initials: 'CC',
    canCreate: false,
    stageIndex: 4
  }
];

export const DEFAULT_BATCHES: BatchItem[] = [
  {
    id: 'TF-2026-00125',
    product: 'Banana',
    variety: 'Hybrid Red-5 (GI Certified)',
    farm: 'GreenValley Agri Farms, Satara',
    mandi: 'Pune Central APMC (Hub-04)',
    quantity: '1,200 Kg (48 Crates)',
    grade: 'Grade A (Premium)',
    registered: 'Just Now',
    condition: 'Fresh · Cold-Chain Normal',
    freshnessScore: 98,
    temp: '4.2 °C',
    price: '₹50 / kg',
    packaging: ['100% Recyclable Crates', 'Zero Plastic Wrap', 'Biodegradable Tag'],
    route: [
      { name: 'Farm Harvest', lat: 17.6805, lng: 74.0183 },
      { name: 'Pune APMC Mandi', lat: 18.5204, lng: 73.8567 },
      { name: 'Transit Highway', lat: 18.5800, lng: 73.8000 },
      { name: 'FreshBazaar Store', lat: 18.5074, lng: 73.8077 }
    ],
    history: [
      {
        stage: '1. Farm Harvest',
        location: 'GreenValley Farm, Satara',
        handler: 'Ramesh Patil (Farmer)',
        timestamp: 'Just Now',
        status: 'Completed',
        note: 'Logged on net-zero chain.'
      },
      {
        stage: '2. APMC Mandi Hub',
        location: 'Pune Central APMC (Hub-04)',
        handler: 'Rajesh Kumar (Mandi Admin)',
        timestamp: 'In Progress',
        status: 'In Progress',
        note: 'Quality clearance active.'
      },
      {
        stage: '3. Cold Transport Dispatch',
        location: 'Reefer Express #MH-12-VT-8890',
        handler: 'Suresh Patil (Logistics)',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'IoT sensor array active.'
      },
      {
        stage: '4. Retail Store Receipt',
        location: 'FreshBazaar Store #104',
        handler: 'Anita Sharma (Store Manager)',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'Stock intake check.'
      },
      {
        stage: '5. Consumer Package Scan',
        location: 'Consumer Checkout QR',
        handler: 'Citizen Customer',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'Final origin proof.'
      }
    ]
  },
  {
    id: 'TF-2026-00127',
    product: 'Alphonso Mangoes (GI Tag)',
    variety: 'Ratnagiri Export Grade',
    farm: 'Ratnagiri Coastal Orchards',
    mandi: 'Vashi APMC Mumbai (Hub-01)',
    quantity: '336 Crates (3,360 Pcs)',
    grade: 'Grade A (Premium)',
    registered: 'Oct 25, 2026',
    condition: '13.5°C',
    freshnessScore: 98,
    temp: '13.5 °C',
    price: '₹180 / kg',
    packaging: ['100% Recyclable Crates', 'Zero Plastic Wrap'],
    route: [
      { name: 'Ratnagiri Orchards', lat: 16.9902, lng: 73.3120 },
      { name: 'Vashi APMC', lat: 19.0770, lng: 73.0000 }
    ],
    history: [
      {
        stage: '1. Farm Harvest',
        location: 'Ratnagiri Coastal Orchards',
        handler: 'Ganesh Shinde (Farmer)',
        timestamp: 'Oct 25, 2026',
        status: 'Completed',
        note: 'Hand Picked'
      },
      {
        stage: '2. APMC Mandi Hub',
        location: 'Vashi APMC Mumbai',
        handler: 'Rajesh Kumar (Mandi Admin)',
        timestamp: 'Oct 25, 2026',
        status: 'Completed',
        note: 'Phytosanitary check passed.'
      },
      {
        stage: '3. Cold Transport Dispatch',
        location: 'Reefer Express',
        handler: 'Suresh Patil',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'Cold transit.'
      },
      {
        stage: '4. Retail Store Receipt',
        location: 'Retail Outlet',
        handler: 'Anita Sharma',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'Awaiting receipt.'
      },
      {
        stage: '5. Consumer Package Scan',
        location: 'Consumer Checkout',
        handler: 'Citizen Customer',
        timestamp: 'Pending Scan',
        status: 'Pending',
        note: 'Consumer proof.'
      }
    ]
  },
  {
    id: 'TF-2026-00129',
    product: 'Kinnaur Royal Gala Apples',
    variety: 'Sweet Juicy Grade A',
    farm: 'High-Land Orchards, HP',
    mandi: 'Azadpur APMC Delhi (Hub-02)',
    quantity: '2,400 Kg (320 Boxes)',
    grade: 'Grade A (Premium)',
    registered: 'Oct 24, 2026',
    condition: '3.0°C',
    freshnessScore: 92,
    temp: '3.0 °C',
    price: '₹120 / kg',
    packaging: ['100% Recyclable Crates', 'Biodegradable Tag'],
    route: [
      { name: 'High-Land Orchards', lat: 31.6520, lng: 78.3300 },
      { name: 'Azadpur APMC', lat: 28.7150, lng: 77.1720 }
    ],
    history: [
      {
        stage: '1. Farm Harvest',
        location: 'High-Land Orchards, HP',
        handler: 'Devendra Singh',
        timestamp: 'Oct 24, 2026',
        status: 'Completed',
        note: 'Harvest Tagged'
      },
      {
        stage: '2. APMC Mandi Hub',
        location: 'Azadpur APMC Delhi',
        handler: 'Rajesh Kumar',
        timestamp: 'Oct 24, 2026',
        status: 'Completed',
        note: 'Mandi Quality Verified'
      }
    ]
  }
];
